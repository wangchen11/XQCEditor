#include "base.h"
#include "Button.h"
#include <stdlib.h>
#include <memory.h>
#include "calculator.h"
#include <math.h>
#define IMGSIZE 4
//如果要使用LOGI,和LOGE请定义LOG_TAG这个宏
#define LOG_TAG  "LOG_TAG"
#define TEXTSIZE 40
#define BUFSIZE 1024

//屏幕宽度
int mScreenW=0;
//屏幕高度
int mScreenH=0;
//屏幕像素密度
float mScreenD=1.0;
jobject mBitmap[IMGSIZE];
PBUTTON headButton = NULL;
char* numberBuf = NULL;//表达式字符串缓存
char* preNumberBuf = NULL;
int bufCount = 0;
char reserve[BUFSIZ];
char clearMark = 0;
char* about = "作者:复制哥 开发工具:快写代码 欢迎加入望尘11开发者群,群号码:136898517";

void menu();
void readBitmap();
void deleteImg();
void showResult();
void insertChar(char);
void keyInputExpression(int );
//在程序启动时调用
void onCreate()
{
	setTextSize(TEXTSIZE);
	readBitmap();
	headButton = initialButton();
	numberBuf = (char* )malloc(BUFSIZ);
	memset(numberBuf, 0, BUFSIZ);
	preNumberBuf = (char* )malloc(BUFSIZE);
	memset(preNumberBuf, 0, BUFSIZ);
    initialCalculator();
}

//触摸事件调用
void onTouchEvent(int action,float x,float y,int index,int count,float pointersX[],float pointersY[],int pointersId[])
{
	int p1 = buttonEvent(headButton, x, y);
	
	static float pre_x = 0;
	static float pre_y = 0;
	static int pre_id = 0;
	if (ACTION_DOWN == action)
	{
	   setButtonBitmap(headButton, p1, mBitmap[1]);
	   pre_y = y;
	   pre_x = x;
	   pre_id = p1;
	}
	if (pre_id == -1)
	{
	   return;
	}
	if (ACTION_UP == action)
	{
		if (pre_x != x && pre_y != y)
		{
			PBUTTON p = seekId(headButton, pre_id);
			if (p != NULL)
			{
			   if (!((p->left <= x) && (p->right >= x) && (p->top <= y) && (p->bottom >= y)))
			   {
		          if (pre_id != 38)
		          {
	                 setButtonBitmap(headButton, pre_id, mBitmap[0]);	 
	              }
		          else
		          {
		             setButtonBitmap(headButton, pre_id, mBitmap[2]);
		          }	
			      postInvalidate();
			      return;
			   }
			}
		}
		if (p1 != 38)
		{
	       setButtonBitmap(headButton, p1, mBitmap[0]);	 
	    }
		else
		{
		   setButtonBitmap(headButton, p1, mBitmap[2]);
		}
		keyInputExpression(p1);

	}
	postInvalidate();
}

//只能在这里绘图
void onDraw(int left,int top,int right,int bottom )
{
	//drawColor(RGB(255, 255, 255));
	
    traverseListDraw(headButton);
	AndroidBitmapInfo bitmapInfo;
	getBitmapInfo(mBitmap[3], &bitmapInfo);
	drawBitmap(mBitmap[3], 0, 0, bitmapInfo.width, bitmapInfo.height, 0, 0, mScreenW, mScreenH/4);
	showResult();

}


//屏幕大小发生变化时被调用 ，程序在启动后会调用一次
void onSizeChange(int w,int h,int oldw,int oldh,float density)
{
	mScreenW=w;
	mScreenH=h;
	mScreenD=density;
	clearButton(headButton);
	menu();
}

//系统每1毫秒就会调用这个方法1次
void onLoopCall()
{
	//postInvalidate();
}

//返回键被按下事件，如果 返回0则退出程序，
int onBackPressed()
{
	return 0;
}

//应用被暂停时调用，例如被后台运行
void onPause()
{
	showToastText("onPause",0);
}

//应用被恢复时调用，例如从后台运行转为前台运行
void onResume()
{
	showToastText("onResume",0);
}

//程序在被销毁时调用
void onDestroy()
{
	deleteImg();
	clearButton(headButton);
	delteButton(&headButton);
	free(numberBuf);
	numberBuf = NULL;
	free(preNumberBuf);
	preNumberBuf = NULL;
	deleteCalculator();
	exit(0);
}
//读取图片
void readBitmap()
{
   mBitmap[0] = decodeBitmapFromAssets("Button.jpg");
   mBitmap[1] = decodeBitmapFromAssets("key.jpg");
   mBitmap[2] = decodeBitmapFromAssets("del.png");
   mBitmap[3] = decodeBitmapFromAssets("Text.jpg");
}
//释放图片
void deleteImg()
{
   int i;
   for (i = 0; i < IMGSIZE; i++)
   {
	   if (mBitmap[i] != NULL)
	   {
          deleteBitmap(mBitmap[i]);
	      mBitmap[i] = NULL;
	  }
   }
}
//界面
void menu()
{
   int i;
   int j;
   int id = 0;
   float top = mScreenH/4;
   float bottom = (mScreenH-top)/8;
   float left = 0;
   float right = mScreenW/5;
   char* title[] = {
   "C", "粘贴", "复制", "关于", "历史", 
   "MC", "MR", "MS", "M+", "M-", 
   "cos", "tan", "n!", "1/x", "π", 
   "(", ")", "^", "x^2", "x^3", 
   "ln", "1", "2", "3", "+", 
   "log", "4", "5", "6", "-", 
   "sin", "7", "8", "9", "×", 
   ".", "=", "0", "DEL", "÷"
   };
   for (i = 0; i < 8; i++)
   {
	   for (j = 0; j < 5; j++)
	   {
          addButton(headButton, id, title[id], left, top, left+right, top+bottom, TEXTSIZE, RGB(255, 255, 255), "Button.jpg");
		  left += right;
		  id++;
	   }
	   left = 0;
	   top += bottom;
   }
   setButtonBitmap(headButton, 38, mBitmap[2]);
   setButtonText(headButton, 0, "C", RGB(255, 0, 0), TEXTSIZE+10, "center");
   setButtonText(headButton, 38, "DEL", RGB(255, 0, 0), TEXTSIZE, "center");
   setButtonText(headButton, 24, "+", RGB(0, 0, 230), TEXTSIZE, "center");
   setButtonText(headButton, 29, "-", RGB(0, 0, 230), TEXTSIZE, "center");
   setButtonText(headButton, 34, "×", RGB(0, 0, 230), TEXTSIZE, "center");
   setButtonText(headButton, 39, "÷", RGB(0, 0, 230), TEXTSIZE, "center");
   
}
//显示输出结果
void showResult()
{
   setColor(RGB(255, 255, 255));
   setTextSize(TEXTSIZE+TEXTSIZE);
   jstring str = createJString(numberBuf);
   float textWidth = measureText(str);
   deleteJString(str);
   drawText(numberBuf, mScreenW - textWidth, mScreenH/4);
   setColor(RGB(158, 158, 158));
   setTextSize(TEXTSIZE+(TEXTSIZE/2));
   str = createJString(preNumberBuf);
   textWidth = measureText(str);
   deleteJString(str);
   drawText(preNumberBuf, mScreenW - textWidth, mScreenH/4-(TEXTSIZE+TEXTSIZE)-50);
}
//输入字符
void insertChar(char c)
{
   if (bufCount < 1024)
   {
	   if (clearMark == 1)
	   {
		  if (c >= '0' && c <= '9')
		  {
	         memset(numberBuf, 0, BUFSIZ);
		     bufCount = 0;
		     clearMark = 0;
		  }
		  else
		  {
		     clearMark = 0;
		  }
	   }
	  if (0 == bufCount && (c == '+' || c == '-' || c == '*' || c == '/' || c == '.' || c == ')' || c == '^'))
	  {
	     return;
	  }else if(numberBuf[bufCount-1] < '0'  && (c < '0' || c == '^'))
	  {
		  
	     switch (numberBuf[bufCount-1])
		 {
		    case '+':
			   if (c != '-' && c != '(')
			   {
				   return;
			   }
			break;
			case '-':
			   if (c != '-' && c != '(')
			   {
			      return;
			   }else if (bufCount-2 >= 0 && numberBuf[bufCount-2] < '0' && numberBuf[bufCount-2] != ')')
			   {
			      return;
			   }
			break;
			case '*':
			   if (c != '-' && c != '(')
			   {
			      return;
			   }
			break;
			case '/':
			   if (c != '-' && c != '(')
			   {
			      return;
			   }
			break;
			case '.':
			   return;
			break;
			case '(':
			   if (c != '-')
			   {
			      return;
			   }
			break;
			case ')':
			   if (c == ')' || c == '.' || c == '(')
			   {
			      return;
			   }
		    break;
			case '^':
			   return;
			break;
		 }
	  }else if (c == ')')
	  {
	     int i = bufCount-1;
		 char flag = 0;
		 for (; i != -1; i--)
		 {
			 if (numberBuf[i] == '(')
			 {
				 flag = 1;
			     break;
			 }
			 if (numberBuf[i] == ')')
			 {
			     return;
			 }
		 }
	     if (flag == 0)
	     {
			 return;
		 }
	  }else if (c == '.')
	  {
	     int i = bufCount-1;
		 for (; i != -1; i--)
		 {
		    if (numberBuf[i] < '0' && numberBuf[i] != '.')
			{
			   break;
			}else if (numberBuf[i] == '.')
			{
			   return;
			}
		 }
	  }else if (bufCount > 0 && c == '(')
	  {
	     if (numberBuf[bufCount-1] >= '0')
		 {
		    return;
		 }
	  }else if(c == '^' && numberBuf[bufCount-1] == '^')
	  {
	     return;
	  }
      numberBuf[bufCount++] = c;
   }
   else
   {
      showToastText("太长了(苦笑)", 0);
   }

}
//删除多余小数
void removePoint(double result)
{
   strcpy(preNumberBuf, numberBuf);
   sprintf(numberBuf, "%lf", result); 
   int len = strlen(numberBuf);
   for (len--; len != -1; len--)
   {
	   if (numberBuf[len] == '0')
	   {
		   numberBuf[len] = 0;
	   }
	   else
	   {
		   if (numberBuf[len] == '.')
		   {
			  numberBuf[len] = 0;
		   }
			   break;
	   }
   }
   bufCount = strlen(numberBuf);
}
//按键输入表达式
void keyInputExpression(int p1)
{
   double result = 0;
   switch(p1)
   {
      case 0://清除所有
	     memset(numberBuf, 0, BUFSIZE);
		 memset(preNumberBuf, 0, BUFSIZE);
		 bufCount = 0;
		 postInvalidate();
	  break;
	  case 1://粘贴
	  break;
	  case 2://复制
	  break;
	  case 3://关于
	     strcpy(preNumberBuf, about);
	  break;
	  case 4://历史
	  break;
	  case 5://MC
	     reserve[0] = 0;
	  break;
	  case 6://MR
	     strcpy(numberBuf, reserve);
		 bufCount = strlen(numberBuf);
	  break;
	  case 7://MS
	     strcpy(reserve, numberBuf);
	  break;
	  case 8://M+
	     {
		    double r = atof(numberBuf);
			double s = atof(reserve);
			result = s + r;
			sprintf(reserve, "%lf", result);
		 }
	  break;
	  case 9://M-
	     {
		    double r = atof(numberBuf);
			double s = atof(reserve);
			result = s - r;
			sprintf(reserve, "%lf", result);
		 }
	  break;
	  case 10://cos
	     result = cos(atof(numberBuf));
		 removePoint(result);
		 clearMark = 1;
	  break;
	  case 11://tan
	     result = tan(atof(numberBuf));
		 removePoint(result);
		 clearMark = 1;
	  break;
	  case 12://n!
	     {
		    double n = atof(numberBuf);
			result = n;
			n--;
			for (; n > 1; n--)
			{
			   result *= n;
			}
		    removePoint(result);
			clearMark = 1;
		 }
	  break;
	  case 13://1/x
	     result = 1.0/atof(numberBuf);
		 removePoint(result);
		 clearMark = 1;
	  break;
	  case 14://π
	     result = atof(numberBuf) * 3.14159265;
		 removePoint(result);
		 clearMark = 1;
	  break;
	  case 15://(
	     insertChar('(');
	  break;
	  case 16://)
	     insertChar(')');
	  break;
	  case 17://^
	     insertChar('^');
	  break;
	  case 18://x^2
	     result = pow(atof(numberBuf), 2);
		 removePoint(result);
		 clearMark = 1;
	  break;
	  case 19://x^3
	     result = pow(atof(numberBuf), 3);
		 removePoint(result);
		 clearMark = 1;
	  break;
	  case 20:
	  break;//ln
	  case 21://1
	     insertChar('1');
	  break;
	  case 22://2
	     insertChar('2');
	  break;
	  case 23://3
	     insertChar('3');
	  break;
	  case 24://+
	     insertChar('+');
	  break;
	  case 25://log
	     result = log(atof(numberBuf));
		 removePoint(result);
		 clearMark = 1;
	  break;
	  case 26://4
	     insertChar('4');
	  break;
	  case 27://5
	     insertChar('5');
	  break;
	  case 28://6
	     insertChar('6');
	  break;
	  case 29://-
	     insertChar('-');
	  break;
	  case 30://sin
	     result = sin(atof(numberBuf));
		 removePoint(result);
		 clearMark = 1;
	  break;
	  case 31://7
	     insertChar('7');
	  break;
	  case 32://8
	     insertChar('8');
	  break;
	  case 33://9
	     insertChar('9');
	  break;
	  case 34://×
	     insertChar('*');
	  break;
	  case 35://.
	     insertChar('.');
	  break;
	  case 36://=
	     if (bufCount > 0)
		 {
	        result = polandExpression(numberBuf);
		    removePoint(result);
		    clearMark = 1;
		 }
	  break;
	  case 37://0
	     insertChar('0');
	  break;
	  case 38://DEL
	     if (bufCount > 0)
		 {
	        numberBuf[--bufCount] = 0;
		 }
	  break;
	  case 39://÷
	     insertChar('/');
	  break;
	  default:
	  break;
   }
}