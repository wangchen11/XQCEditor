/***
作者:复制哥
2016年8月26日
***/

#include "base.h"
#include "Button.h"
#include <stdlib.h>
#include <string.h>
//如果要使用LOGI,和LOGE请定义LOG_TAG这个宏
#define  LOG_TAG    "LOG_TAG"

#define HORIZONTAL_COUNT_MAX 30//横最大格数
#define VERTICAL_COUNT_MAX 30//坚最大格数
#define IMG_SIZE 4
#define RAY_COUNT 80//地雷的最大数量
#define INIT_HORIZONTAL_COUNT 14
#define INIT_VERTICAL_COUNT 20

int HORIZONTAL_COUNT;
int VERTICAL_COUNT;
//屏幕宽度
int mScreenW=0;
//屏幕高度
int mScreenH=0;
//屏幕像素密度
float mScreenD=1.0;
jobject mBitmap[IMG_SIZE];
PBUTTON pHeadButton = NULL;
PBUTTON controlButton = NULL;
PBUTTON pxy = NULL;
short raYareA[HORIZONTAL_COUNT_MAX*VERTICAL_COUNT_MAX];//扫雷区域
int raYcounT = 10;//初始化2个雷
int flagsTag = 10;//插旗子标记
int bitmapXY[16][4];//block图片绘制区域
int gameTime = 0;//游戏时间
int ImgTimeXY[12][4];//时间图片绘制区域

void gameMenu();
void gameBackground();
void readImg();
void deleteImg();
void randRay();
void showDigitalArea(int, int);
void outShowRay();
int victory();
void showRayCount();
void showTime();
void timerStart();

//初始化雷区的数组
void initialRayArea()
{
   int i;
   for (i = 0; i < HORIZONTAL_COUNT_MAX*VERTICAL_COUNT_MAX; i++)
   {
      raYareA[i] = 0;
   }
}
//图片绘制的区域
void initialImgxy()
{
   int j;
   int i;
   int xyData[4] = {0, 240, 16, 256};
   for (i = 0; i < 16; i++)
   {
      for (j = 0; j < 4; j++)
	  {
	     bitmapXY[i][j] = xyData[j];
	  }
	  xyData[3] = xyData[1];
	  xyData[1] -= 16;	  
   }
}
void initialImgTimeXY()
{
   int j;
   int i;
   int xyData[4] = {0, 253, 14, 276};
   for (i = 0; i < 12; i++)
   {
      for (j = 0; j < 4; j++)
	  {
	     ImgTimeXY[i][j] = xyData[j];
	  }
	  xyData[3] = xyData[1];
	  xyData[1] -= 23;	  
   }
}
void clearGridBuf()
{
   int i;
   for (i = 0; i < HORIZONTAL_COUNT*VERTICAL_COUNT; i++)
   {
      setButtonBitmapDrawArea(pHeadButton, i, 0, 0, 16, 16);
   }
   
   for (i = 0; i < 7; i++)
   {
	  if (i == 3)
	  {
	     continue;
	  }
      setButtonBitmapDrawArea(controlButton, i, ImgTimeXY[0][0], ImgTimeXY[0][1], ImgTimeXY[0][2], ImgTimeXY[0][3]);
   }
   /* HORIZONTAL_COUNT = INIT_HORIZONTAL_COUNT;
	VERTICAL_COUNT = INIT_VERTICAL_COUNT;
	clearButton(pHeadButton);
	gameMenu();*/
}
//在程序启动时调用
void onCreate()
{
	pHeadButton  = createButton();
	controlButton = createButton();
	HORIZONTAL_COUNT = INIT_HORIZONTAL_COUNT;
	VERTICAL_COUNT = INIT_VERTICAL_COUNT;
	flagsTag = raYcounT;
	readImg();
	initialRayArea();
	initialImgxy();
	randRay();
	initialImgTimeXY();
}

//触摸事件调用
void onTouchEvent(int action,float x,float y,int index,int count,float pointersX[],float pointersY[],int pointersId[])
{
    int type = 0;
	int type2 = 0;
	PBUTTON pxl = seekId(controlButton, 3);
	PBUTTON pFlagTag = seekId(controlButton, 7);
    int p1 = buttonEvent(pHeadButton, &type, x, y);
    int p2 = buttonEvent(controlButton, &type2, x, y);	
	pxy = seekId(pHeadButton, p1);
	if (0 == type2)
	{
	   if (3 == p2)
	   {
		  if (pxl->fromTop == 48)
	      {
			 setButtonBitmapDrawArea(controlButton, 3, 0, 96, 24, 120);
			 initialRayArea();
			 randRay();
			 clearGridBuf();
			 flagsTag = raYcounT;
		  }else if (pxl->fromTop == 24)
		  {
			 flagsTag = raYcounT;
			 gameTime = 0;
			 setButtonBitmapDrawArea(controlButton, 3, 0, 96, 24, 120);
			 setButtonBitmapDrawArea(controlButton, 7, bitmapXY[15][0], bitmapXY[15][1], bitmapXY[15][2], bitmapXY[15][3]);
			 initialRayArea();
			 randRay();
		     clearButton(pHeadButton);
	         gameMenu();            
             setButtonBitmapDrawArea(controlButton, 4, ImgTimeXY[0][0], ImgTimeXY[0][1], ImgTimeXY[0][2], ImgTimeXY[0][3]);
			 setButtonBitmapDrawArea(controlButton, 5, ImgTimeXY[0][0], ImgTimeXY[0][1], ImgTimeXY[0][2], ImgTimeXY[0][3]);
			 setButtonBitmapDrawArea(controlButton, 6, ImgTimeXY[0][0], ImgTimeXY[0][1], ImgTimeXY[0][2], ImgTimeXY[0][3]);
		  }
	   }
    }
	if (pxl->fromTop == 48 || pxl->fromTop == 24)
	{
	    return;
	}
	if (ACTION_DOWN == action)
	{	   
	   if (1 == type)
	   {
		  
	      if (pxl->fromTop == 96 && raYareA[p1] != -1)
	      {
	         setButtonBitmapDrawArea(controlButton, 3, 0, 72, 24, 96);
	      }
	      
	   }
	   else if (0 == type2)
	   {
		  if (7 == p2)
		  {
	         if (pFlagTag->fromTop == 0)
		     {
		        setButtonBitmapDrawArea(controlButton, p2, bitmapXY[14][0], bitmapXY[14][1], bitmapXY[14][2], bitmapXY[14][3]);
		     }else if (pFlagTag->fromTop == 16)
			 {
			    setButtonBitmapDrawArea(controlButton, p2, bitmapXY[15][0], bitmapXY[15][1], bitmapXY[15][2], bitmapXY[15][3]);
			 }
		  }
	   }
	   
	}
	if (ACTION_UP == action)
	{
	   if (1 == type)
       {
		   if (pxl != NULL && pxy != NULL)
		   {		      		     
			  if (pxl->fromTop != 48 && pFlagTag->fromTop != 16 && pxy->fromTop != bitmapXY[14][1] && pxy->fromTop != bitmapXY[10][1])
			  {
			      if (raYareA[p1] == 10)
				  {
					 setButtonBitmapDrawArea(pHeadButton, p1, bitmapXY[raYareA[p1]+2][0], bitmapXY[raYareA[p1]+2][1], bitmapXY[raYareA[p1]+2][2], bitmapXY[raYareA[p1]+2][3]);
		             setButtonBitmapDrawArea(controlButton, 3, 0, 48, 24, 72);					 
					 outShowRay();
					 pxy = NULL;
					 gameTime = 0;
					 postInvalidate();
					 return;
				  }
		          if (raYareA[p1] != -1 && pxy->fromTop != bitmapXY[14][1] && pxy->fromTop != bitmapXY[10][1])
		          {
			         if(raYareA[p1] == 0)
					 {
					    showDigitalArea(p1, rand()%20);
					 }
					 else
					 {
	                    setButtonBitmapDrawArea(pHeadButton, p1, bitmapXY[raYareA[p1]][0], bitmapXY[raYareA[p1]][1], bitmapXY[raYareA[p1]][2], bitmapXY[raYareA[p1]][3]);
					    raYareA[p1] = -1;
					 }
		          }
		             setButtonBitmapDrawArea(controlButton, 3, 0, 96, 24, 120);
		      }
		      else
			  {
				 if (raYareA[p1] != -1)
				 {
					if (pxy->fromTop == 0)
					{
					   setButtonBitmapDrawArea(pHeadButton, p1, bitmapXY[14][0], bitmapXY[14][1], bitmapXY[14][2], bitmapXY[14][3]);
					   flagsTag--;
					}else if (pxy->fromTop == bitmapXY[14][1])
					{
					   setButtonBitmapDrawArea(pHeadButton, p1, bitmapXY[9][0], bitmapXY[9][1], bitmapXY[9][2], bitmapXY[9][3]);
					   flagsTag++;
				    }else if (pxy->fromTop == bitmapXY[9][1])
					{
					   setButtonBitmapDrawArea(pHeadButton, p1, bitmapXY[15][0], bitmapXY[15][1], bitmapXY[15][2], bitmapXY[15][3]);
					}
			     }
				 if (victory() == 1)
				 {
				    setButtonBitmapDrawArea(controlButton, 3, 0, 24, 24, 48);
					pxy = NULL;
					gameTime = 0;
				 }
			  }		      
		   }		   
	    }
     }
	
	postInvalidate();
}

//只能在这里绘图
void onDraw(int left,int top,int right,int bottom )
{
	gameBackground();
	traverseListDraw(controlButton);
	traverseListDraw(pHeadButton);
	if (pxy != NULL)
	{
	   drawBitmap(mBitmap[2], 0, 0, 22, 22, pxy->left, pxy->top, pxy->right, pxy->bottom);
	}
	
}
//系统每1毫秒就会调用这个方法1次
void onLoopCall()
{
	timerStart();
}
//屏幕大小发生变化时被调用 ，程序在启动后会调用一次
void onSizeChange(int w,int h,int oldw,int oldh,float density)
{
	mScreenW=w;
	mScreenH=h;
	mScreenD=density;
	gameMenu();
}

//返回键被按下事件，如果 返回0则退出程序，
int onBackPressed()
{
	return 0;
}

//应用被暂停时调用，例如被后台运行
void onPause()
{
	showToastText("onPause",0);
}

//应用被恢复时调用，例如从后台运行转为前台运行
void onResume()
{
	showToastText("onResume",0);
}

//程序在被销毁时调用
void onDestroy()
{
	clearButton(pHeadButton);
	deleteButton(&pHeadButton);
	clearButton(controlButton);
	deleteButton(&controlButton);
	deleteImg();
	exit(0);
}
//读取图片
void readImg()
{
   mBitmap[0] = decodeBitmapFromAssets("block.png");
   mBitmap[1] = decodeBitmapFromAssets("num.png");
   mBitmap[2] = decodeBitmapFromAssets("focus.png");
   mBitmap[3] = decodeBitmapFromAssets("face.png");
   
}
//释放图片内存
void deleteImg()
{
   int i;
   for (i = 0; i < IMG_SIZE; i++)
   {
      if (mBitmap[i] != NULL)
	  {
	     deleteBitmap(mBitmap[i]);
		 mBitmap[i] = NULL;
	  }
   }
}
//背景 控制器
void gameBackground()
{
   static char cflag = 0;
   int id = 0;
   int i;
   drawColor(RGB(192, 192, 192));
   setColor(RGB(128, 128, 128));
   float left = (float)mScreenW/20.0;
   float top = left;
   float right = (float)mScreenW-left;
   float bottom = (float)mScreenH/7.0-left;
   float width = left-left/4;
   float height = top-top/4;
   drawRect(width, height, right+left/4, height+top/4);
   drawRect(width, height, width+left/4, bottom);
   setColor(RGB(255, 255, 255));
   drawRect(width, bottom, right+left/4, bottom+top/4);
   drawRect((right+left/4)-left/4, height, right+left/4, bottom+top/4);
   setColor(RGB(128, 128, 128));
   height = bottom+left;
   drawRect(width, height-top/4, right+left/4, height);
   drawRect(width, height-top/4, width+left/4, mScreenH-top+top/4);
   setColor(RGB(255, 255, 255));
   drawRect((right+left/4)-left/4, height-top/4, right+left/4, mScreenH-top+top/4);
   drawRect(width, mScreenH-top, right+left/4, mScreenH-top+top/4);
 
   float left2 = left+left/2;
   float top2 = top+top/2;
   float right2 = left;
   float bottom2 = bottom-(top2-top);
   for (i = 0; i < 3; i++)
   {
      drawBitmap(mBitmap[1], 0, 23, 14, 46, left2, top2, left2+right2, bottom2);
	  if (cflag == 0)
	  {
         addButton(controlButton, 0, id, "", left2, top2, left2+right2, bottom2, 0, 0, "0x000000");
	     setButtonBackground(controlButton, id, 0, mBitmap[1]);
	     setButtonBitmapDrawArea(controlButton, id, 0, 253, 14, 276);
	  }
      left2 += right2;
	  id++;
   }
   left2 = (float)mScreenW/2.0-left/2;
   right2 = left2+left*2;   
   if (cflag == 0)
   {
      addButton(controlButton, 0, id++, "", left2, top2, right2, bottom2, 0, 0, "0x000000");
      setButtonBackground(controlButton, 3, 0, mBitmap[3]);
      setButtonBitmapDrawArea(controlButton, 3, 0, 96, 24, 120);
   }
   right2 = right-left/2;
   left2 = right2-left;
   for (i = 3; i > 0; i--)
   {
      drawBitmap(mBitmap[1], 0, 23, 14, 46, left2, top2, right2, bottom2);
	  if (cflag == 0)
	  {
         addButton(controlButton, 0, id, "", left2, top2, right2, bottom2, 0, 0, "0x000000");
	     setButtonBackground(controlButton, id, 0, mBitmap[1]);
	     setButtonBitmapDrawArea(controlButton, id, 0, 253, 14, 276);
	  }
      right2 = left2;
	  left2 = right2-left;
	  id++;
   }
   float left3 = (((float)mScreenW/2.0-left/2+left*2)+(left2+left))/2-left/2;
   if (cflag == 0)
   {
      addButton(controlButton, 0, id++, "", left3, top2+top2/4, left3+left, bottom2-top2/4, 0, 0, "0x000000");
      setButtonBackground(controlButton, 7, 0, mBitmap[0]);
      setButtonBitmapDrawArea(controlButton, 7, 0, 0, 16, 16);
   }
   cflag = 1;
   showRayCount();
}
//游戏界面
void gameMenu()
{
    int i;
	int j;
	float left = (float)mScreenW/20.0;
	float top = (float)mScreenH/7.0;
	float right = ((float)mScreenW-left*2)/HORIZONTAL_COUNT;
	float bottom = ((float)mScreenH-top-left)/VERTICAL_COUNT;
	int id = 0;
	for (i = 0; i < VERTICAL_COUNT; i++)
	{
	   for (j = 0; j < HORIZONTAL_COUNT; j++)
	   {
	      addButton(pHeadButton, 1, id, "", left, top, left+right, top+bottom, 100, 0, "0xffffff");
		  setButtonBackground(pHeadButton, id, 0, mBitmap[0]);
		  setButtonBitmapDrawArea(pHeadButton, id, 0, 0, 16, 16);
		  left += right;
		  id++;
	   }
	   left = (float)mScreenW/20.0;
	   top += bottom;
	}

}
//随机设置地雷
void randRay()
{
 
   int* record = (int* )malloc(raYcounT*4);
   int i;
   int id = 0;
   int t = 0;
   for (i = 0; i < raYcounT; i++)
   {
      id = rand()%(HORIZONTAL_COUNT*VERTICAL_COUNT);
	  if (raYareA[id] == 0)
	  {
	     raYareA[id] = 10;//10表示雷
		 record[t++] = id;
	  }
	  else if (raYareA[id] == 10)
	  {
	     i--;
	  }
   }
  int j = 0;
  int flag = 0;
  int flag2 = 0;
  for (i = 0; i < raYcounT; i++)
  {
     for (j = 0; j < HORIZONTAL_COUNT*VERTICAL_COUNT; j += HORIZONTAL_COUNT)
	 {
	    if (record[i] == j)
		{
		   break;
		}
	 }
	 if (j != record[i])
	 {
		if (raYareA[record[i]-1] != 10)
		{
		   raYareA[record[i]-1]++;
		}
		flag = 1;
	 }
	 else
	 {
	    flag = 0;
	 }
	 for (j = HORIZONTAL_COUNT-1; j < HORIZONTAL_COUNT*VERTICAL_COUNT; j += HORIZONTAL_COUNT)
	  {
	      if (record[i] == j)
		  {
		     break;
		  }
	  }
	  if (j != record[i])
	  {
	     if (raYareA[record[i]+1] != 10)
		 {
		    raYareA[record[i]+1]++;
		 }
		 flag2 = 1;
	  }
	  else
	  {
	     flag2 = 0;
	  }
	 if (record[i] - HORIZONTAL_COUNT >= 0)
     {
		   if (raYareA[record[i]-HORIZONTAL_COUNT] != 10)
		   {
		      raYareA[record[i]-HORIZONTAL_COUNT]++;
		   }
		   if (flag == 1 && raYareA[record[i]-HORIZONTAL_COUNT-1] != 10)
		   {
		      raYareA[record[i]-HORIZONTAL_COUNT-1]++;
		   }
		   if (flag2 == 1 && raYareA[record[i]-HORIZONTAL_COUNT+1] != 10)
		   {
		      raYareA[record[i]-HORIZONTAL_COUNT+1]++;
		   }
	 }
	 if (record[i] + HORIZONTAL_COUNT < HORIZONTAL_COUNT*VERTICAL_COUNT)
	 {
	    if (raYareA[record[i]+HORIZONTAL_COUNT] != 10)
		{
		   raYareA[record[i]+HORIZONTAL_COUNT]++;
		}
		if (flag == 1 && raYareA[record[i]+HORIZONTAL_COUNT-1] != 10)
		{
		   raYareA[record[i]+HORIZONTAL_COUNT-1]++;
		}
		if (flag2 == 1 && raYareA[record[i]+HORIZONTAL_COUNT+1] != 10)
		{
		   raYareA[record[i]+HORIZONTAL_COUNT+1]++;
		}
	 }
  }
  free(record);
  record = NULL;

}

//非数字的时候，随机显示周围格子
void showDigitalArea(int nodeId, int ranDnumber)
{
	  PBUTTON p = seekId(pHeadButton, nodeId);
	  int poinTbuf[4] = {-1, -1, -1, -1};
	  int i;
	  if (raYareA[nodeId] != -1 && raYareA[nodeId] != 10 && p->fromTop != bitmapXY[14][1] && p->fromTop != bitmapXY[10][1])
	  {
	     setButtonBitmapDrawArea(pHeadButton, nodeId, bitmapXY[raYareA[nodeId]][0], bitmapXY[raYareA[nodeId]][1], bitmapXY[raYareA[nodeId]][2], bitmapXY[raYareA[nodeId]][3]);
	     raYareA[nodeId] = -1;
	  }
	  for (i = 0; i < HORIZONTAL_COUNT*VERTICAL_COUNT; i += HORIZONTAL_COUNT)
	  {
	     if (nodeId == i)
		 {
		    break;
		 }
	  }
	  if (nodeId != i)
	  {
		  p = seekId(pHeadButton, nodeId-1);
		  if (raYareA[nodeId-1] != -1 && raYareA[nodeId-1] != 10 && p->fromTop != bitmapXY[14][1] && p->fromTop != bitmapXY[10][1])
		  {
	         setButtonBitmapDrawArea(pHeadButton, nodeId-1, bitmapXY[raYareA[nodeId-1]][0], bitmapXY[raYareA[nodeId-1]][1], bitmapXY[raYareA[nodeId-1]][2], bitmapXY[raYareA[nodeId-1]][3]);
			 raYareA[nodeId-1] = -1;
		     poinTbuf[0] = nodeId-1;
		  }
	  }
	  if (nodeId - HORIZONTAL_COUNT >= 0)
	  {
		  p = seekId(pHeadButton, nodeId-HORIZONTAL_COUNT);
		  if (raYareA[nodeId-HORIZONTAL_COUNT] != -1 && raYareA[nodeId-HORIZONTAL_COUNT] != 10 && p->fromTop != bitmapXY[14][1] && p->fromTop != bitmapXY[10][1])
		  {
	         setButtonBitmapDrawArea(pHeadButton, nodeId-HORIZONTAL_COUNT, bitmapXY[raYareA[nodeId-HORIZONTAL_COUNT]][0], bitmapXY[raYareA[nodeId-HORIZONTAL_COUNT]][1], bitmapXY[raYareA[nodeId-HORIZONTAL_COUNT]][2], bitmapXY[raYareA[nodeId-HORIZONTAL_COUNT]][3]);	
		     raYareA[nodeId-HORIZONTAL_COUNT] = -1;
		     poinTbuf[1] = nodeId-HORIZONTAL_COUNT;
		  }
	   }
	  for (i = HORIZONTAL_COUNT-1; i < HORIZONTAL_COUNT*VERTICAL_COUNT; i += HORIZONTAL_COUNT)
	  {
	      if (nodeId == i)
		  {
		     break;
		  }
	  }
	  if (nodeId != i)
	  {
		  p = seekId(pHeadButton, nodeId+1);
		  if (raYareA[nodeId+1] != -1 && raYareA[nodeId+1] != 10 && p->fromTop != bitmapXY[14][1] && p->fromTop != bitmapXY[10][1])
		  {
	         setButtonBitmapDrawArea(pHeadButton, nodeId+1, bitmapXY[raYareA[nodeId+1]][0], bitmapXY[raYareA[nodeId+1]][1], bitmapXY[raYareA[nodeId+1]][2], bitmapXY[raYareA[nodeId+1]][3]);
			 raYareA[nodeId+1] = -1;
		     poinTbuf[2] = nodeId+1;
		  }
	  }
	  if (nodeId + HORIZONTAL_COUNT < HORIZONTAL_COUNT*VERTICAL_COUNT)
	  {
		  p = seekId(pHeadButton, nodeId+HORIZONTAL_COUNT);
	     if (raYareA[nodeId+HORIZONTAL_COUNT] != -1 && raYareA[nodeId+HORIZONTAL_COUNT] != 10 && p->fromTop != bitmapXY[14][1] && p->fromTop != bitmapXY[10][1])
		 {
		    setButtonBitmapDrawArea(pHeadButton, nodeId+HORIZONTAL_COUNT, bitmapXY[raYareA[nodeId+HORIZONTAL_COUNT]][0], bitmapXY[raYareA[nodeId+HORIZONTAL_COUNT]][1], bitmapXY[raYareA[nodeId+HORIZONTAL_COUNT]][2], bitmapXY[raYareA[nodeId+HORIZONTAL_COUNT]][3]);
		    raYareA[nodeId+HORIZONTAL_COUNT] = -1;
            poinTbuf[3] = nodeId+HORIZONTAL_COUNT;
		 }
	  }
      if (ranDnumber == 0)//回归
	  {
	     return;
	  }
	  else
	  {
		 if (poinTbuf[0] == -1 && poinTbuf[1] == -1 && poinTbuf[2] == -1 && poinTbuf[3] == -1)
		 {
		    return;
		 }
		 int n = rand()%4;
		 while (poinTbuf[n] == -1)
		 {
			n = rand()%4;
		 }
		 //随机获取上下左右一个大小负1的点，进行递归 
		 showDigitalArea(poinTbuf[n], --ranDnumber);
	  }
   
}
//输了显示地雷
void outShowRay()
{
   int i;
   for (i = 0; i < HORIZONTAL_COUNT*VERTICAL_COUNT; i++)
   {
      if (raYareA[i] == 10)
	  {
	     setButtonBitmapDrawArea(pHeadButton, i, bitmapXY[10][0], bitmapXY[10][1], bitmapXY[10][2], bitmapXY[10][3]);
	  }
   }
}
//胜利了
int victory()
{
   if (flagsTag == 0)//进行排雷
   {
      PBUTTON p = NULL;
	  int i;
	  for (i = 0; i < HORIZONTAL_COUNT* VERTICAL_COUNT; i++)
	  {
	     if (raYareA[i] == 10)
		 {
		    p = seekId(pHeadButton, i);
			if (p->fromTop != bitmapXY[14][1])
			{
			   return 0;
			}
		 }
	  }
	  for (i = 0; i < HORIZONTAL_COUNT*VERTICAL_COUNT; i++)
	  {
		  if (raYareA[i] == 10)
		  {
			  setButtonBitmapDrawArea(pHeadButton, i, bitmapXY[14][0], bitmapXY[14][1], bitmapXY[14][2], bitmapXY[14][3]);
		  }
		  else if (raYareA[i] != -1)
		  {
		     setButtonBitmapDrawArea(pHeadButton, i, bitmapXY[raYareA[i]][0], bitmapXY[raYareA[i]][1], bitmapXY[raYareA[i]][2], bitmapXY[raYareA[i]][3]);
		  }
	  }
	  if (VERTICAL_COUNT < VERTICAL_COUNT_MAX)
	  {
	     VERTICAL_COUNT += 1;
	  }
	  if (HORIZONTAL_COUNT < HORIZONTAL_COUNT_MAX)
	  {
	     HORIZONTAL_COUNT += 1;
	  }
	  if (raYcounT < RAY_COUNT)
	  {
	     raYcounT += 5;//每次加5个雷
	  }
	
	  postInvalidate();
	  showToastText("好棒哦！请点击人头进行下一关", 1);
	  return 1;
   }
   else
   {
      return 0;
   }
}
//显示地雷的数量和时间 
void showRayCount()
{
   char buf[30];
   char time[2];
   sprintf(buf, "%d", flagsTag);
   PBUTTON p = NULL;
   int i;
   int n = atoi(buf);
   if (n < -99)
   {
      for (i = 0; i < 3; i++)
	  {
	     setButtonBitmapDrawArea(controlButton, i, ImgTimeXY[11][0], ImgTimeXY[11][1], ImgTimeXY[11][2], ImgTimeXY[11][3]);	     
	  }
	  return;
   }
      for (i = 0; i < 3; i++)
	  {
	     setButtonBitmapDrawArea(controlButton, i, ImgTimeXY[0][0], ImgTimeXY[0][1], ImgTimeXY[0][2], ImgTimeXY[0][3]);	     
	  }

   
   
   int len = strlen(buf);
   for (i = 2; i >= 0 && len != 0; i--)
   {
	  time[0] = buf[len-1];
	  time[1] = '\0';
	  len--;
	  if (time[0] == '-')
	  {
		  setButtonBitmapDrawArea(controlButton, 0, ImgTimeXY[11][0], ImgTimeXY[11][1], ImgTimeXY[11][2], ImgTimeXY[11][3]);
	  }
      else
	  {
         n = atoi(time);	  
	     p = seekId(controlButton, i);
	     if (p != NULL)
	     {
	        setButtonBitmapDrawArea(controlButton, i, ImgTimeXY[n][0], ImgTimeXY[n][1], ImgTimeXY[n][2], ImgTimeXY[n][3]);
	     }
	  }
   }
}
//显示时间
void showTime()
{
   if (gameTime > 1000)
   {
      gameTime = 0;
   }
   char buf[30];
   char time[2];
   sprintf(buf, "%d", gameTime);
   PBUTTON p = NULL;
   int i;
   int n;
   int len = strlen(buf);
   for (i = 4; i <= 6 && len != 0; i++)
   {
	  time[0] = buf[len-1];
	  time[1] = '\0';
	  len--;
      n = atoi(time);
	  p = seekId(controlButton, i);
	  if (p != NULL)
	  {
	     setButtonBitmapDrawArea(controlButton, i, ImgTimeXY[n][0], ImgTimeXY[n][1], ImgTimeXY[n][2], ImgTimeXY[n][3]);
	  }
   }
}
//定时器回调函数
void timerStart()
{
    static long long proTime=0;
	//每1000毫秒执行一次
	if(currentTimeMillis()-proTime>1000)
	{
		proTime=currentTimeMillis();	
		if (pxy != NULL)
		{
			showTime();
			gameTime++;
	    	postInvalidateRect(0, 0, mScreenW, mScreenH/7);
		}
	}
}