#include "base.h"
#include <stdlib.h>
#include <string.h>
/*typedef struct textview
{
   int id;
   char* text;
   float left;
   float top;
   float right;
   float bottom;
   float textX;
   float textY;
   int textSize;
   int textColor;
   int backBackground;
   jobject bitmap;
}TextView, *pTextView;
*/
//自定义换行 例如:"aa\naa"
int showText(const char* text, float x, float y, int textSize, int textColor)
{
	int len = strlen(text);
	char* buf = (char* )malloc(len+1);
	strcpy(buf, text);
	setTextSize(textSize);
	setColor(textColor);
	int i;
	char* p = buf;
	for (i = 0; buf[i] != 0; i++)
	{
	   if (buf[i] == '\n')
	   {
	      buf[i] = 0;
		  drawText(p, x, y+textSize);
		  p = &buf[i+1];
		  y += textSize;
	   }
	}
	drawText(p, x, y+textSize);
	free(buf);
	buf = NULL;
	
	return 0;
}