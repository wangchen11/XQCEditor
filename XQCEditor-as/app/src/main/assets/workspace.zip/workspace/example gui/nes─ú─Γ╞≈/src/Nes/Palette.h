#pragma once
extern uint32_t Palette[];
void initPalette();