#include "calculator.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
static PSTACK Headstack;
void initialCalculator()
{
   Headstack = initialStack();
}
void deleteCalculator()
{
   deleteStack(&Headstack);
}
//判断运算符优先级
static int judge_priority(char c)
{
    switch(c)
    {
        case ')':
        return 1;
        break;
        case '(':
        return 2;
        break;
        case '|':
        return 3;
        break;
        case '&':
        return 5;
        break;
        case '<':
        return 6;
        break;
        case '>':
        return 7;
        break;
        case '-':
        case '+':
        return 8;
        break;
        case '*':
        case '/':
        case '%':
        return 9;
        case '^':
        return 10;
        break;
        case '~':
        return 11;
        break;
        
    }
        
     
    return -1;
 
}

/*
计算结果

*/
double polandExpression(const char* text)
{
   
    int i = 0;
	int j = 0;
    double e;
    double interim = 0;
    double interim2 = 0;
    int len = strlen(text);
    char* buf = (char* )malloc(len*2+20);
    memset(buf, 0, len*2+20);
    char str[300];
    char c;
    for (j = 0; j < len; j++)
    {
		c = text[j];
        if ((c >= '0' && c <= '9') || c == '.')
        {   
           buf[i++] = c; 
           
           continue;
        }
        else
        if (i != 0 && buf[i-1] != ' ')
        {           
            buf[i++] = ' '; 
        }
        if(')' == c)
        {
            
            pop(Headstack, &e);
            while('(' != e)
            {
                buf[i++] = (char)e;
                buf[i++] = ' ';
                pop(Headstack, &e);
                
            }
        }
        else if('+' == c || '-' == c || '*' == c || '/' == c || '%' == c || '^' == c 
        || '|' == c || '&' == c || '~' == c || '<' == c || '>' == c)
             {
                if ('-' == text[j+1])
                {
                    buf[i++] = text[j+1];
                    j++;
                }
                if('<' == c || '>' == c)
                {
                    c = text[j+1];
					j++;
                }
                
                 if(!stackLen(Headstack))//为空的时候才入栈
                 {
                
                     push(Headstack, c);
                 }
                 else
                 {   
                    while(stackLen(Headstack) && judge_priority((char)Headstack->top->data) >= judge_priority(c))
                    {
                        pop(Headstack, &e);
                        buf[i++] = (char)e;                        
                        buf[i++] = ' ';
                    }
                    
                    push(Headstack, c);
                   
                }
             }
             else if('(' == c )
             {                                                                           
                if ('-' == text[j+1])
                {
                    buf[i++] = text[j+1];
                    j++;
                }
                 push(Headstack, c);                                               
             }
             
       
    }
    
    while(stackLen(Headstack))
    {
        buf[i++] = ' ';
        pop(Headstack, &e);
        buf[i++] = (char)e;
        
    }
    buf[i++] = ' ';
    char* p = buf;
	len = i;
    i = 0;
    for (j = 0; j < len; j++)
    {
		c = p[j];
        while((c >= '0' && c <= '9') || c == '.')
        {
            str[i++] = c;           
            c = p[++j];
            if(i >= 300)
            {
                free(buf);
                return 0;
             }
            if(' ' == c)
            {                            
                str[i] = '\0';
                interim = atof(str);
                push(Headstack, interim);
                i = 0;
                break;
            }
            
        }
        
        switch(c)
        {
            case '+':
            pop(Headstack, &interim2);
            pop(Headstack, &interim);
            push(Headstack, interim+interim2);
            break;
            case '-':
            if (p[j+1] != ' ')
            {
                str[i++] = '-';
                break;
            }
            pop(Headstack, &interim2);
            pop(Headstack, &interim);
            push(Headstack, interim-interim2);
            break;
            case '*':
            pop(Headstack, &interim2);
            pop(Headstack, &interim);
            push(Headstack, interim*interim2);
            break;
            case '/':
            pop(Headstack, &interim2);
            pop(Headstack, &interim);
            if(interim2 != 0)
            {
                push(Headstack, interim/interim2);
            }
            else
            {
               free(buf);
               return 0;
            }
            break;
            
            case '^':            
               pop(Headstack, &interim2);
               pop(Headstack, &interim);
               push(Headstack, pow(interim, interim2));
            
            break;
             
            default:
            
            break;
        }
		
    }
    pop(Headstack, &interim);
    
    return interim;
}