
#include <jni.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <android/bitmap.h>

#include <android/log.h>

#define  LOG_TAG    "NativeView"
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)


void canvasSave();
void canvasRestore();
void canvasClipRect(float left,float top,float right,float bottom);
void canvasRotate(float degrees,float px,float py);
void canvasTranslate(float dx,float dy);
void canvasScale(float sx,float sy,float px,float py);
void drawColor(int color);
void setColor(int color);
void setTextSize(float size);
void drawLine( float startX,float startY,float stopX,float stopY);
void drawText(const char * text,float x,float y);
void invalidate();
void postInvalidate();
void invalidateRect(int left,int top,int right,int bottom);
void postInvalidateRect(int left,int top,int right,int bottom);
void drawRect(float left, float top, float right, float bottom);
void drawRoundRect(float left, float top, float right, float bottom,float rx,float ry);
jobject decodeBitmapFromAssets(jstring name);
jobject decodeBitmapFromFile(jstring path);
jobject createBitmap(int width,int height);
void deleteBitmap(jobject bitmap);
void getBitmapInfo(jobject bitmap,AndroidBitmapInfo *bitmapInfo);
void drawBitmap(jobject bitmap,int fromLeft,int fromTop,int fromRight,int fromBottom,float toLeft,float toTop,float toRight,float toBottom);
float measureTextEx(jstring string,int start,int end);
float measureText(jstring string);
void finish();
typedef void (*EditTextCallback) ( jstring string,int cur );
static EditTextCallback mOnSure=NULL;
static EditTextCallback mOnCancel=NULL;
int requestEditText(jstring title,jstring string,int cur,EditTextCallback onSure,EditTextCallback onCancel);
void showToast(jstring string,int time);
void deleteJString(jstring string);
int lengthOfJString(jstring string);
jstring createJString(const char* text);
long long currentTimeMillis();
long long nanoTime();
void showToastText(const char *text,int time);
void *readAllFromAssets(const char *name,int *outLength);

struct Method_st{
	jmethodID methodID;
	char * methodName;
	char * methodParm;
};
typedef struct Method_st Method;

struct MethodIds_st{
	//public static void setStrokeWidth(float width)
	Method setStrokeWidth;
	//public static void setStroke(boolean stroke)
	Method setStroke;
	//public static void canvasSave()
	Method canvasSave;

	//public static void canvasRestore()
	Method canvasRestore;
	//public static void canvasClipRect(float left,float top,float right,float bottom)
	Method canvasClipRect;
	//public static void canvasRotate(float degrees,float px,float py)
	Method canvasRotate;
	//public static void canvasTranslate(float dx,float dy)
	Method canvasTranslate;
	//public static void canvasScale(float sx, float sy, float px, float py)
	Method canvasScale;

	//public static void drawColor(int color)
	Method drawColor;
	//public static void setColor(int color)
	Method setColor;
	//public static void setTextSize(float size)
	Method setTextSize;
	//public static void drawLine(float startX,float startY,float stopX,float stopY)
	Method drawLine;
	//void drawText(String text,int start,int end,float x,float y)
	Method drawText;

	//public static void drawRect(float left, float top, float right, float bottom)
	Method drawRect;
	//public static void drawRoundRect(float left, float top, float right, float bottom,float rx,float ry)
	Method drawRoundRect;
    //public static void invalidate()
	Method invalidate;
	//public static void postInvalidate()
	Method postInvalidate;
	//public static void invalidateRect(int left,int top,int right,int bottom)
	Method invalidateRect;

	//public static void postInvalidateRect(int left,int top,int right,int bottom)
	Method postInvalidateRect;
	//public static Bitmap decodeBitmapFromAssets(String name)
	Method decodeBitmapFromAssets;
	//public static Bitmap decodeBitmapFromFile(String path)
	Method decodeBitmapFromFile;
	//public static Bitmap createBitmap(int width,int height)
	Method createBitmap;
	//public static void drawBitmap(Bitmap bitmap,int fromLeft,int fromTop,int fromRight,int fromBottom,float toLeft,float toTop,float toRight,float toBottom)
	Method drawBitmap;

	//public float measureText(String text,int start,int end)
	Method measureText;
	//public static void finish()
	Method finish;
	//public boolean requestEditText(String title,String string,int cur)
	Method requestEditText;
	//public static void showToast(String string,int time)
	Method showToast;
	//public static long currentTimeMillis();
	Method currentTimeMillis;

	//public static long nanoTime();
	Method nanoTime;
	//public static byte []readAllFromAssets(String name)
	Method readAllFromAssets;
	//public static MediaPlayer createMediaPlayer()
	Method createMediaPlayer;
	//public static boolean mediaPlayerSetSourceFromAssert(MediaPlayer mediaPlayer,String path)
	Method mediaPlayerSetSourceFromAssert;
	//public static boolean mediaPlayerSetSourceFromPath(MediaPlayer mediaPlayer,String path)
	Method mediaPlayerSetSourceFromPath;

	//public static boolean mediaPlayerPrepare(MediaPlayer mediaPlayer)
	Method mediaPlayerPrepare;
	//public static boolean mediaPlayerStart(MediaPlayer mediaPlayer)
	Method mediaPlayerStart;
	//public static boolean mediaPlayerStop(MediaPlayer mediaPlayer)
	Method mediaPlayerStop;
	//public static boolean mediaPlayerReset(MediaPlayer mediaPlayer)
	Method mediaPlayerReset;
	//public static boolean mediaPlayerRlease(MediaPlayer mediaPlayer)
	Method mediaPlayerRlease;

	//public static boolean mediaPlayerPause(MediaPlayer mediaPlayer)
	Method mediaPlayerPause;
	//public static boolean mediaPlayerSetLooping(MediaPlayer mediaPlayer,boolean looping)
	Method mediaPlayerSetLooping;
	//public static boolean mediaPlayerIsLooping(MediaPlayer mediaPlayer)
	Method mediaPlayerIsLooping;
	//public static boolean mediaPlayerIsPlaying(MediaPlayer mediaPlayer)
	Method mediaPlayerIsPlaying;
	//public static boolean mediaPlayerSetVolume(MediaPlayer mediaPlayer,float leftVolume,float rightVolume)
	Method mediaPlayerSetVolume;

	//public static boolean mediaPlayerSeekTo(MediaPlayer mediaPlayer,int msec)
	Method mediaPlayerSeekTo;
	//public static int mediaPlayerGetDuration(MediaPlayer mediaPlayer)
	Method mediaPlayerGetDuration;
	//public static int mediaPlayerGetCurrentPosition(MediaPlayer mediaPlayer)
	Method mediaPlayerGetCurrentPosition;
} mMethods =
{
		{NULL,"setStrokeWidth"	,"(F)V"},
		{NULL,"setStroke"	,"(Z)V"},
		{NULL,"canvasSave"	,"()V"},

		{NULL,"canvasRestore"	,"()V"},
		{NULL,"canvasClipRect"	,"(FFFF)V"},
		{NULL,"canvasRotate"	,"(FFF)V"},
		{NULL,"canvasTranslate"	,"(FF)V"},
		{NULL,"canvasScale"	,"(FFFF)V"},

		{NULL,"drawColor"	,"(I)V"},
		{NULL,"setColor"	,"(I)V"},
		{NULL,"setTextSize"	,"(F)V"},
		{NULL,"drawLine"	,"(FFFF)V"},
		{NULL,"drawText"	,"(Ljava/lang/String;IIFF)V"},

		{NULL,"drawRect"	,"(FFFF)V"},
		{NULL,"drawRoundRect"	,"(FFFFFF)V"},
		{NULL,"invalidate"		,"()V"},
		{NULL,"postInvalidate"	,"()V"},
		{NULL,"invalidateRect"	,"(IIII)V"},

		{NULL,"postInvalidateRect"	,"(IIII)V"},
		{NULL,"decodeBitmapFromAssets"	,"(Ljava/lang/String;)Landroid/graphics/Bitmap;"},
		{NULL,"decodeBitmapFromFile"	,"(Ljava/lang/String;)Landroid/graphics/Bitmap;"},
		{NULL,"createBitmap"	,"(II)Landroid/graphics/Bitmap;"},
		{NULL,"drawBitmap"		,"(Landroid/graphics/Bitmap;IIIIFFFF)V"},

		{NULL,"measureText"		,"(Ljava/lang/String;II)F"},
		{NULL,"finish"			,"()V"},
		{NULL,"requestEditText"	,"(Ljava/lang/String;Ljava/lang/String;I)Z"},
		{NULL,"showToast"		,"(Ljava/lang/String;I)V"},
		{NULL,"currentTimeMillis"	,"()J"},

		{NULL,"nanoTime"		,"()J"},
		{NULL,"readAllFromAssets"		,"(Ljava/lang/String;)[B"},
		{NULL,"createMediaPlayer"		,"()Landroid/media/MediaPlayer;"},
		{NULL,"mediaPlayerSetSourceFromAssert"		,"(Landroid/media/MediaPlayer;Ljava/lang/String;)Z"},
		{NULL,"mediaPlayerSetSourceFromPath"		,"(Landroid/media/MediaPlayer;Ljava/lang/String;)Z"},

		{NULL,"mediaPlayerPrepare"		,"(Landroid/media/MediaPlayer;)Z"},
		{NULL,"mediaPlayerStart"		,"(Landroid/media/MediaPlayer;)Z"},
		{NULL,"mediaPlayerStop"			,"(Landroid/media/MediaPlayer;)Z"},
		{NULL,"mediaPlayerReset"		,"(Landroid/media/MediaPlayer;)Z"},
		{NULL,"mediaPlayerRlease"		,"(Landroid/media/MediaPlayer;)Z"},

		{NULL,"mediaPlayerPause"		,"(Landroid/media/MediaPlayer;)Z"},
		{NULL,"mediaPlayerSetLooping"		,"(Landroid/media/MediaPlayer;Z)Z"},
		{NULL,"mediaPlayerIsLooping"		,"(Landroid/media/MediaPlayer;)Z"},
		{NULL,"mediaPlayerIsPlaying"		,"(Landroid/media/MediaPlayer;)Z"},
		{NULL,"mediaPlayerSetVolume"		,"(Landroid/media/MediaPlayer;FF)Z"},

		{NULL,"mediaPlayerSeekTo"			,"(Landroid/media/MediaPlayer;I)Z"},
		{NULL,"mediaPlayerGetDuration"		,"(Landroid/media/MediaPlayer;)I"},
		{NULL,"mediaPlayerGetCurrentPosition"		,"(Landroid/media/MediaPlayer;)I"},
};



JNIEnv* mEnv;
jclass mClazz;


extern void onCreate();
void Java_person_wangchen11_nativeview_NativeInterface_init
( JNIEnv* env,jclass clazz )
{
	int i;
	Method *methods=(Method *)&mMethods;
	int methodsSize=sizeof(mMethods)/sizeof(Method);
	mEnv=env;
	mClazz=clazz;
	for(i=0;i<methodsSize;i++)
	{
		methods[i].methodID=(*env)->GetStaticMethodID(env,clazz,methods[i].methodName,methods[i].methodParm);
	}
	onCreate();
}

#define MAX_POINTER_NUMBER 10
static float mPointersX[MAX_POINTER_NUMBER];
static float mPointersY[MAX_POINTER_NUMBER];
static int  mPointersID[MAX_POINTER_NUMBER];

extern void onTouchEvent(int action,float x,float y,int index,int count,float pointersX[],float pointersY[],int pointersId[]);
jboolean Java_person_wangchen11_nativeview_NativeInterface_touchEvent
( JNIEnv* env,jclass clazz,jint action,jfloat x,jfloat y,jint index,jint count
		,jfloatArray pointersX,jfloatArray pointersY,jintArray pointersId)
{
	mClazz=clazz;
	(*mEnv)->GetFloatArrayRegion(mEnv,pointersX,0,count,mPointersX);
	(*mEnv)->GetFloatArrayRegion(mEnv,pointersY,0,count,mPointersY);
	(*mEnv)->GetIntArrayRegion(mEnv,pointersId,0,count,mPointersID);
	onTouchEvent(action,x,y,index,count,mPointersX,mPointersY,mPointersID);
	return 1;
}

extern void onDraw(int left,int top,int right,int bottom );
void Java_person_wangchen11_nativeview_NativeInterface_draw
( JNIEnv* env,jclass clazz,jint left,jint top,jint right,jint bottom )
{
	mClazz=clazz;
	onDraw(left,top,right,bottom);
}

extern void onSizeChange(int w,int h,int oldw,int oldh,float density);
void Java_person_wangchen11_nativeview_NativeInterface_sizeChange
( JNIEnv* env,jclass clazz,jint w,jint h,jint oldw,jint oldh,jfloat density)
{
	mClazz=clazz;
	onSizeChange(w,h,oldw,oldh,density);
}

extern void onDestroy();
void Java_person_wangchen11_nativeview_NativeInterface_destroy
( JNIEnv* env,jclass clazz)
{
	mClazz=clazz;
	onDestroy();
}

extern int onBackPressed();
jboolean Java_person_wangchen11_nativeview_NativeInterface_backPressed
( JNIEnv* env,jclass clazz)
{
	mClazz=clazz;
	return onBackPressed();
}

void Java_person_wangchen11_nativeview_NativeInterface_onEditTextCancel
( JNIEnv* env,jclass clazz,jstring string ,jint cur)
{
	mClazz=clazz;
	if(mOnCancel!=NULL)
	{
		string = (*mEnv)->NewGlobalRef(mEnv,string);
		mOnCancel(string ,cur);
	}
	mOnCancel=NULL;
	mOnSure=NULL;
}

void Java_person_wangchen11_nativeview_NativeInterface_onEditTextSure
( JNIEnv* env,jclass clazz,jstring string ,jint cur)
{
	mClazz=clazz;
	if(mOnSure!=NULL)
	{
		string = (*mEnv)->NewGlobalRef(mEnv,string);
		mOnSure(string ,cur);
	}
	mOnCancel=NULL;
	mOnSure=NULL;
}

void onLoopCall();
void Java_person_wangchen11_nativeview_NativeInterface_onLoopCall
( JNIEnv* env,jclass clazz)
{
	mClazz=clazz;
	onLoopCall();
}

void onPause();
void Java_person_wangchen11_nativeview_NativeInterface_onPause
( JNIEnv* env,jclass clazz)
{
	mClazz=clazz;
	onPause();
}

void onResume();
void Java_person_wangchen11_nativeview_NativeInterface_onResume
( JNIEnv* env,jclass clazz)
{
	mClazz=clazz;
	onResume();
}


void setStrokeWidth(float width)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.setStrokeWidth.methodID,width);
}

void setStroke(jboolean stroke)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.setStroke.methodID,stroke);
}


void canvasSave()
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.canvasSave.methodID);
}

void canvasRestore()
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.canvasRestore.methodID);
}

void canvasClipRect(float left,float top,float right,float bottom)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.canvasClipRect.methodID,left,top,right,bottom);
}

void canvasRotate(float degrees,float px,float py)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.canvasRotate.methodID,degrees,px,py);
}

void canvasTranslate(float dx,float dy)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.canvasTranslate.methodID,dx,dy);
}

void canvasScale(float sx,float sy,float px,float py)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.canvasScale.methodID,sx,sy,px,py);
}

void drawColor(int color)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.drawColor.methodID,color);
}

void setColor(int color)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.setColor.methodID,color);
}

void setTextSize(float size)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.setTextSize.methodID,size);
}

void drawLine( float startX,float startY,float stopX,float stopY)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.drawLine.methodID,startX,startY,stopX,stopY);
}

jstring createJString(const char* text)
{
	jstring string=(*mEnv)->NewStringUTF(mEnv,text);
	return (*mEnv)->NewGlobalRef(mEnv,string);
}

void deleteJString(jstring string)
{
	(*mEnv)->DeleteGlobalRef(mEnv,string);
}

int lengthOfJString(jstring string)
{
	return (*mEnv)->GetStringLength(mEnv,string);
}


char * getJStringChars(jstring string)
{
	char *ret=NULL;
	const char *chars=(*mEnv)->GetStringUTFChars(mEnv,string,NULL);
	ret = (char *)malloc(strlen(chars)+2);
	strcpy(ret,chars);
	(*mEnv)->ReleaseStringUTFChars(mEnv,string,chars);
	return ret;
}

void drawText(const char* text,float x,float y)
{
	jstring string=createJString(text);
	int len=lengthOfJString(string);
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.drawText.methodID,string,0,len,x,y);
	deleteJString(string);
}

void drawString(jstring string,float x,float y)
{
	int len=lengthOfJString(string);
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.drawText.methodID,string,0,len,x,y);
}

void drawRect(float left, float top, float right, float bottom)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.drawRect.methodID,left,top,right,bottom);
}

void drawRoundRect(float left, float top, float right, float bottom,float rx,float ry)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.drawRoundRect.methodID,left,top,right,bottom,rx,ry);
}

void invalidate()
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.invalidate.methodID);
}

void postInvalidate()
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.postInvalidate.methodID);
}
void invalidateRect(int left,int top,int right,int bottom)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.invalidateRect.methodID,left,top,right,bottom);
}
void postInvalidateRect(int left,int top,int right,int bottom)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.postInvalidateRect.methodID,left,top,right,bottom);
}

jobject decodeBitmapFromAssets(jstring name)
{
	jstring string=(*mEnv)->NewStringUTF(mEnv,name);
	jobject obj= (*mEnv)->CallStaticObjectMethod(mEnv,mClazz,mMethods.decodeBitmapFromAssets.methodID,string);
	(*mEnv)->DeleteLocalRef(mEnv,string);
	return (*mEnv)->NewGlobalRef(mEnv,obj);
}

jobject decodeBitmapFromFile(jstring path)
{
	jstring string=(*mEnv)->NewStringUTF(mEnv,path);
	jobject obj= (*mEnv)->CallStaticObjectMethod(mEnv,mClazz,mMethods.decodeBitmapFromFile.methodID);
	(*mEnv)->DeleteLocalRef(mEnv,string);
	return (*mEnv)->NewGlobalRef(mEnv,obj);
}

jobject createBitmap(int width,int height)
{
	jobject obj= (*mEnv)->CallStaticObjectMethod(mEnv,mClazz,mMethods.createBitmap.methodID,width,height);
	return (*mEnv)->NewGlobalRef(mEnv,obj);
}

void deleteBitmap(jobject bitmap)
{
	(*mEnv)->DeleteGlobalRef(mEnv,bitmap);
}

void getBitmapInfo(jobject bitmap,AndroidBitmapInfo *bitmapInfo)
{
	AndroidBitmap_getInfo(mEnv,bitmap,bitmapInfo);
}

void drawBitmap(jobject bitmap
		,int fromLeft,int fromTop,int fromRight,int fromBottom
		,float toLeft,float toTop,float toRight,float toBottom)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.drawBitmap.methodID,bitmap
			,fromLeft,fromTop,fromRight,fromBottom
			,toLeft,toTop,toRight,toBottom);
}

float measureText(jstring string)
{
	return measureTextEx(string,0,lengthOfJString(string));
}

float measureTextEx(jstring string,int start,int end)
{
	return (*mEnv)->CallStaticFloatMethod(mEnv,mClazz,mMethods.measureText.methodID,string,start,end);
}

void finish()
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.finish.methodID);
}


int requestEditText(jstring title,jstring string,int cur,EditTextCallback onSure,EditTextCallback onCancel)
{
	jboolean ret=(*mEnv)->CallStaticBooleanMethod(mEnv,mClazz,mMethods.requestEditText.methodID,title,string,cur);
	if(ret == 0)//return false
	{
		return ret;
	}
	mOnSure=onSure;
	mOnCancel=onCancel;
	return ret;
}

void showToast(jstring string,int time)
{
	(*mEnv)->CallStaticVoidMethod(mEnv,mClazz,mMethods.showToast.methodID,string,time);
}

void showToastText(const char *text,int time)
{
	jstring string=createJString(text);
	showToast(string,time);
	deleteJString(string);
}

long long currentTimeMillis()
{
	return (*mEnv)->CallStaticLongMethod(mEnv,mClazz,mMethods.currentTimeMillis.methodID);
}

long long nanoTime()
{
	return (*mEnv)->CallStaticLongMethod(mEnv,mClazz,mMethods.nanoTime.methodID);
}

void *readAllFromAssets(const char *name,int *outLength)
{
	jstring string=createJString(name);
	jarray array=(*mEnv)->CallStaticObjectMethod(mEnv,mClazz,mMethods.readAllFromAssets.methodID,string);
	deleteJString(string);
	if(array==NULL)
	{
		*outLength=-1;
		return NULL;
	}
	*outLength=(*mEnv)->GetArrayLength(mEnv,array);
	if(*outLength<0)
	{
		*outLength=-1;
		return NULL;
	}
	void *retData=(void *)malloc(*outLength+2);
	if(retData==NULL)
	{
		LOGE("readAllFromAssets:out of memory!");
		*outLength=-1;
		return NULL;
	}
	memset(retData,0,*outLength+2);
	(*mEnv)->GetByteArrayRegion(mEnv,array,0,*outLength,(jbyte*)retData);
	return retData;
}


jobject createMediaPlayer()
{
	jobject mediaPlayer= (*mEnv)->CallStaticObjectMethod(mEnv,mClazz,mMethods.createMediaPlayer.methodID);
	return (*mEnv)->NewGlobalRef(mEnv,mediaPlayer);
}

jboolean deleteMediaPlayer(jobject mediaPlayer)
{
	jboolean ret = (*mEnv)->CallStaticBooleanMethod(mEnv,mClazz,mMethods.mediaPlayerRlease.methodID,mediaPlayer);
	(*mEnv)->DeleteGlobalRef(mEnv,mediaPlayer);
	return ret;
}

jboolean mediaPlayerSetSourceFromAssert(jobject mediaPlayer,const char *path)
{
	jstring string = createJString(path);
	jboolean ret = (*mEnv)->CallStaticBooleanMethod(mEnv,mClazz,mMethods.mediaPlayerSetSourceFromAssert.methodID,mediaPlayer,string);
	deleteJString(string);
	return ret;
}

jboolean mediaPlayerSetSourceFromPath(jobject mediaPlayer,const char *path)
{
	jstring string = createJString(path);
	jboolean ret = (*mEnv)->CallStaticBooleanMethod(mEnv,mClazz,mMethods.mediaPlayerSetSourceFromPath.methodID,mediaPlayer,string);
	deleteJString(string);
	return ret;
}

jboolean mediaPlayerPrepare(jobject mediaPlayer)
{
	jboolean ret = (*mEnv)->CallStaticBooleanMethod(mEnv,mClazz,mMethods.mediaPlayerPrepare.methodID,mediaPlayer);
	return ret;
}

jboolean mediaPlayerStart(jobject mediaPlayer)
{
	jboolean ret = (*mEnv)->CallStaticBooleanMethod(mEnv,mClazz,mMethods.mediaPlayerStart.methodID,mediaPlayer);
	return ret;
}

jboolean mediaPlayerStop(jobject mediaPlayer)
{
	jboolean ret = (*mEnv)->CallStaticBooleanMethod(mEnv,mClazz,mMethods.mediaPlayerStop.methodID,mediaPlayer);
	return ret;
}

jboolean mediaPlayerReset(jobject mediaPlayer)
{
	jboolean ret = (*mEnv)->CallStaticBooleanMethod(mEnv,mClazz,mMethods.mediaPlayerReset.methodID,mediaPlayer);
	return ret;
}

jboolean mediaPlayerPause(jobject mediaPlayer)
{
	jboolean ret = (*mEnv)->CallStaticBooleanMethod(mEnv,mClazz,mMethods.mediaPlayerPause.methodID,mediaPlayer);
	return ret;
}

jboolean mediaPlayerSetLooping(jobject mediaPlayer,jboolean looping)
{
	jboolean ret = (*mEnv)->CallStaticBooleanMethod(mEnv,mClazz,mMethods.mediaPlayerSetLooping.methodID,mediaPlayer,looping);
	return ret;
}

jboolean mediaPlayerIsLooping(jobject mediaPlayer)
{
	jboolean ret = (*mEnv)->CallStaticBooleanMethod(mEnv,mClazz,mMethods.mediaPlayerIsLooping.methodID,mediaPlayer);
	return ret;
}

jboolean mediaPlayerIsPlaying(jobject mediaPlayer)
{
	jboolean ret = (*mEnv)->CallStaticBooleanMethod(mEnv,mClazz,mMethods.mediaPlayerIsPlaying.methodID,mediaPlayer);
	return ret;
}

jboolean mediaPlayerSetVolume(jobject mediaPlayer,float leftVolume,float rightVolume)
{
	jboolean ret = (*mEnv)->CallStaticBooleanMethod(mEnv,mClazz,mMethods.mediaPlayerSetVolume.methodID,mediaPlayer,leftVolume,rightVolume);
	return ret;
}

jboolean mediaPlayerSeekTo(jobject mediaPlayer,int ms)
{
	jboolean ret = (*mEnv)->CallStaticBooleanMethod(mEnv,mClazz,mMethods.mediaPlayerSeekTo.methodID,mediaPlayer,ms);
	return ret;
}

int mediaPlayerGetDuration(jobject mediaPlayer)
{
	int ret = (*mEnv)->CallStaticIntMethod(mEnv,mClazz,mMethods.mediaPlayerGetDuration.methodID,mediaPlayer);
	return ret;
}

int mediaPlayerGetCurrentPosition(jobject mediaPlayer)
{
	int ret = (*mEnv)->CallStaticIntMethod(mEnv,mClazz,mMethods.mediaPlayerGetCurrentPosition.methodID,mediaPlayer);
	return ret;
}


