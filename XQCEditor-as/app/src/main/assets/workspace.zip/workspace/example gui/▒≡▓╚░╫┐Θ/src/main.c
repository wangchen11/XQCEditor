#include "base.h"
#include "Button.h"
#include <stdio.h>
#include <stdlib.h>

//屏幕宽度
int mScreenW=0;
//屏幕高度
int mScreenH=0;
//屏幕像素密度
float mScreenD=1.0;
PBUTTON pHeadButton = NULL;
int timerSpeed = 0;
int tagId = 0;
int score = 0;
int toSpeed = 0;

//如果要使用LOGI,和LOGE请定义LOG_TAG这个宏
#define  LOG_TAG    "LOG_TAG"
#define TEXTSIZE 100
#define SPEED 30
#define HORIZONTAL_COUNT 5
#define VERTICAL_COUNT 4
#define TIME_INTERIM 40
void menu();
void gameMenu();
void drawRandBlackRect(int, int);
void drectSport(PBUTTON);
void timeInterim();
void reset();
//在程序启动时调用
void onCreate()
{
	setTextSize(TEXTSIZE);
	pHeadButton = createButton();
	timerSpeed = TIME_INTERIM;
}

//触摸事件调用
void onTouchEvent(int action,float x,float y,int index,int count,float pointersX[],float pointersY[],int pointersId[])
{
	int type = 0;
	int id = buttonEvent(pHeadButton, &type, x, y);
	if (ACTION_DOWN == action)
	{
		if (0 == type)
		{
	       if (0 == id)//新的开始
	       {
	         clearButton(pHeadButton);
	         gameMenu();
		     postInvalidate();
	         tagId = 1;
		     toSpeed = 50;
		     score = 0;
			 timerSpeed = TIME_INTERIM;
			 return;
	       }
		   if (1 == id)//历史记录
		   {
		       FILE* fp;
               fp = fopen("/storage/emulated/0/aa.txt", "rb");
               if (fp != NULL)
               {
                  fread(&score, 1, sizeof(score), fp);
	              fclose(fp);
				  tagId = 2;
				  postInvalidate();
               }
			 
			  return;
		   }
		   if (2 == id)
		   {
		      showToastText("只能点击黑块哦", 0);
			  return;
		   }
		   if (3 == id)
		   {
		      showToastText("复制哥作品", 0);
			  return;
		   }
		   if (4 == id)
		   {
		      finish();
		   }
		  
	        return;
	   }
	   if (1 == type)
	   {
		  PBUTTON p;
	      p = seekId(pHeadButton, id);
		  if (p != NULL)
		  {
		     if (p->drawRectColor == RGB(255, 255, 255))
			 {
			    reset();
				return;
			 }
			 else
			 {
			    PBUTTON index = p->Next;
				if (index == pHeadButton || p->id >= (VERTICAL_COUNT+1)*HORIZONTAL_COUNT-HORIZONTAL_COUNT)
				{
					index = pHeadButton->Next;
				}
				while (index != pHeadButton && p->bottom == index->bottom)
				{
				   index = index->Next;
				}
				int i;
				for (i = 0; index != pHeadButton && i < HORIZONTAL_COUNT; i++)
				{
				   if (index->drawRectColor == RGB(0, 0, 0))
				   {
				      reset();
					  return;
				   }
				   index = index->Next;
				}
				if (tagId == 1)
				{
				   p->drawRectColor = RGB(255, 255, 255);
				   if (score >= toSpeed)
				   {
				      toSpeed = score+50;
					  if (timerSpeed >= 5)
					  {
					     timerSpeed -= 5;
						 showToastText("加速", 0);
					  }
				   }
				   score++;
				}
				
			 }
		  }
	   }
	}
}

//只能在这里绘图
void onDraw(int left,int top,int right,int bottom )
{
	drawColor(RGB(0, 0, 0));
	traverseListDraw(pHeadButton);
	if (tagId == 1)
	{
    	char scoreBuf[30];
	    sprintf(scoreBuf, "得分%d", score);
	    setColor(RGB(255, 0, 0));
	    setTextSize(TEXTSIZE);
     	drawText(scoreBuf, 0, TEXTSIZE);
	}else if(tagId == 2)
	{
	    drawColor(RGB(255, 255, 255));
		char buf[30];
		sprintf(buf, "历史最高%d分", score);
		setColor(RGB(0, 0, 0));
		setTextSize(TEXTSIZE);
		jstring str = createJString(buf);
		int textWidth = measureText(str);
		deleteJString(str);
		drawText(buf, mScreenW/2-textWidth/2, mScreenH/2-TEXTSIZE/2);
	}
	
}


//屏幕大小发生变化时被调用 ，程序在启动后会调用一次
void onSizeChange(int w,int h,int oldw,int oldh,float density)
{
	mScreenW=w;
	mScreenH=h;
	mScreenD=density;
	menu();	
}

//系统每1毫秒就会调用这个方法1次
void onLoopCall()
{
	if (tagId == 1) 
	{
	   timeInterim();
	}
}

//返回键被按下事件，如果 返回0则退出程序，
int onBackPressed()
{
	if (tagId == 2)
	{
	   tagId = 0;
	   postInvalidate();
	   return 1;
	}
	return 0;
}

//应用被暂停时调用，例如被后台运行
void onPause()
{
	//showToastText("onPause",0);
}

//应用被恢复时调用，例如从后台运行转为前台运行
void onResume()
{
	//showToastText("onResume",0);
}

//程序在被销毁时调用
void onDestroy()
{
	clearButton(pHeadButton);
	deleteButton(&pHeadButton);
	exit(0);
}
//主界面
void menu()
{
   float left = 0;
   float right = mScreenW;
   float top = 0;
   float bottom = mScreenH/5;
   char* title[] = 
   {
      "新的开始", 
	  "历史记录", 
	  "游戏帮助", 
	  "游戏关于", 
	  "退出游戏"
   };
   int color[] = 
   {
      RGB(0, 0, 0), 
	  RGB(255, 255,255), 
	  RGB(0, 0, 0), 
	  RGB(255, 255,255), 
	  RGB(0, 0, 0)
   };
   char* bacnkground[] = 
   {
      "0xffffff", 
	  "0x000000", 
	  "0xffffff", 
	  "0x000000", 
	  "0xffffff"
   };
   
   int i;
   for (i = 0; i < 5; i++)
   {	   
      addButton(pHeadButton, 0, i, title[i], left, top, right, top+bottom, TEXTSIZE, color[i], bacnkground[i]);
	  top += bottom;
   }
   postInvalidate();
}
//游戏界面
void gameMenu()
{
   
   float left = 0;
   float right = mScreenW/HORIZONTAL_COUNT;
   float top = (~(mScreenH/VERTICAL_COUNT))+1;
   float bottom = mScreenH/VERTICAL_COUNT;
   int id = 0;
   int i;
   int j;
   for (i = 0; i < VERTICAL_COUNT+1; i++)
   {
      for (j = 0; j < HORIZONTAL_COUNT; j++)
	  {
	     addButton(pHeadButton, 1, id++, "", left, top, left+right, top+bottom, TEXTSIZE, RGB(255, 255, 255), "0xffffff");
		 left += right+2;
	  }
	  left = 0;
	  top += bottom+2;
	}
   drawRandBlackRect(0, 5);   
}

//绘制随机黑块
void drawRandBlackRect(int min, int max)
{
	int id;
	id = rand()%(max-min+1) + min;
	setButtonBacnkground(pHeadButton, id, RGB(0, 0, 0), NULL);
}
//矩形循环运动
void drectSport(PBUTTON p)
{
    if (p == NULL || p->Next == p)
	{
	   return;
	}
	PBUTTON q = p->Next;
	char flag = 0;
	int i;
	for (i = 0; q != pHeadButton && i < (VERTICAL_COUNT+1)*HORIZONTAL_COUNT; i++)
	{
	   
		  if (q->bottom >= mScreenH)
		  { 
	     	if (q->drawRectColor == RGB(0, 0, 0))
		    {
			  reset();
			  return;
		    }
		  }
	      q->top += SPEED;
	      q->bottom += SPEED;
		  
	      if (q->top >= mScreenH)
		  {			 
		     int t = mScreenH - (q->top-SPEED);
			 q->top = (~(mScreenH/VERTICAL_COUNT))+1-t;
			 if (i >= (VERTICAL_COUNT+1)*HORIZONTAL_COUNT-HORIZONTAL_COUNT)
		     {
				q->bottom = p->Next->top-2;
		     }
			 else
			 {
		        q->bottom = (~t)+1;
			 }
			 flag++;
			 if (flag == HORIZONTAL_COUNT)
			 {
			    drawRandBlackRect(q->id-(HORIZONTAL_COUNT-1), q->id);
				flag = 0;
			 }
		  }
	   
	   q = q->Next;
	}
	
}
void timeInterim()
{
   	static long long proTime=0;

	if(currentTimeMillis()-proTime>timerSpeed)
	{
		proTime=currentTimeMillis();	
		drectSport(pHeadButton);
		postInvalidate();//通知系统重新绘图
	}
}
void reset()
{
   tagId = 0;
   showToastText("挑战失败", 1);
   clearButton(pHeadButton);
   menu();
   int recordScore = -1;
   FILE* fp;
   fp = fopen("/storage/emulated/0/aa.txt", "rb");
   if (fp != NULL)
   {
      fread(&recordScore, 1, sizeof(recordScore), fp);
	  fclose(fp);
   }
   if (recordScore < score)
   {
	   
      fp = fopen("/storage/emulated/0/aa.txt", "wb");
	  if (fp != NULL)
	  {
         fwrite(&score, 1, sizeof(score), fp);
         fclose(fp);
	  }
	  else
	  {
	     fp = fopen("/storage/sdcard1/aa.txt", "wb");
		 if (fp != NULL)
		 {
		    fwrite(&score, 1, sizeof(score), fp);
            fclose(fp);
		 }
	  }
   }
   return;
}
