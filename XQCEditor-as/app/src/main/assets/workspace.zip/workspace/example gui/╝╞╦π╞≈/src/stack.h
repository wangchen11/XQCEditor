#ifndef STACK_H_
#define STACK_H_
#include <stdlib.h>

typedef struct snode
{
   double data;
   struct snode* Next;
}SNODE, *PSNODE;
typedef struct stack
{
   PSNODE top;
   PSNODE bottom;
}STACK, *PSTACK;
extern PSTACK initialStack();//初始化
extern int push(PSTACK, double);//压栈
extern int stackLen(PSTACK);
extern int pop(PSTACK, double* );//出栈
extern int clearStack(PSTACK);//清空栈
extern void deleteStack(PSTACK*);//销毁
#endif