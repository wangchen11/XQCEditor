#include <stdint.h>
#include <memory.h>
#include <stdio.h>
#include "Cartridge.h"
#include "iNes.h"
#include "utils.h"

uint32_t iNESFileMagic = 0x1a53454e;
uint32_t CPUFrequency = 1789773;

#define nullptr NULL

Cartridge* LoadNESFile(const char* path)
{
	// open file
	FILE *f = fopen(path, "rb");
	//fseek(f, 0, SEEK_SET);

	// read file header
	iNESFileHeader header;
	fread(&header, sizeof(header), 1, f);

	// verify header magic number
	if (header.Magic != iNESFileMagic) {
		log("Invalid .nes file");
		return nullptr;
	}

	// mapper type
	int mapper1 = header.Control1 >> 4;
	int mapper2 = header.Control2 >> 4;
	int mapper = mapper1 | mapper2 << 4;

	// mirroring type
	int mirror1 = header.Control1 & 1;
	int mirror2 = (header.Control1 >> 3) & 1;
	int mirror = mirror1 | mirror2 << 1;

	// battery-backed RAM
	int battery = (header.Control1 >> 1) & 1;

	// read trainer if present (unused)
	if ((header.Control1 & 4) == 4) {
		uint8_t* trainer = new uint8_t[512];
		fread(trainer, 512, 1, f);
		delete trainer;
	}

	// read prg-rom bank(s)
	int prg_len = int(header.NumPRG) * 16384;
	uint8_t* prg = new uint8_t[prg_len];
	fread(prg, prg_len, 1, f);

	int chr_len;
	uint8_t* chr;
	// provide chr-rom/ram if not in file
	if (header.NumCHR == 0) {
		chr_len = 8192;
		chr = new uint8_t[8192];
	}
	// read chr-rom bank(s)
	else {
		chr_len = int(header.NumCHR) * 8192;
		chr = new uint8_t[chr_len];
		fread(chr, chr_len, 1, f);
	}

	fclose(f);
	
	log("Mapper: %d", mapper);
	log("Mirror: %d", mirror);
	log("Battery: %d", battery);
	log("PRG: %dK", header.NumPRG * 16);
	log("CHR: %dK", header.NumCHR * 8);

	// success
	return new Cartridge(prg, prg_len, chr, chr_len, mapper, mirror, battery);
}


Cartridge* LoadNESRom(const char* data,int length)
{
	int pos = 0;
	iNESFileHeader header;

	memcpy(&header,data+pos,sizeof(header));
	pos += sizeof(header);
	//fread(&header, sizeof(header), 1, f);

	// verify header magic number
	if (header.Magic != iNESFileMagic) {
		log("Invalid .nes file");
		return nullptr;
	}

	// mapper type
	int mapper1 = header.Control1 >> 4;
	int mapper2 = header.Control2 >> 4;
	int mapper = mapper1 | mapper2 << 4;

	// mirroring type
	int mirror1 = header.Control1 & 1;
	int mirror2 = (header.Control1 >> 3) & 1;
	int mirror = mirror1 | mirror2 << 1;

	// battery-backed RAM
	int battery = (header.Control1 >> 1) & 1;

	// read trainer if present (unused)
	if ((header.Control1 & 4) == 4) {
		uint8_t* trainer = new uint8_t[512];

		memcpy(&trainer,data+pos,512);
		pos += 512;
		//fread(trainer, 512, 1, f);
		delete trainer;
	}

	// read prg-rom bank(s)
	int prg_len = int(header.NumPRG) * 16384;
	uint8_t* prg = new uint8_t[prg_len];

	memcpy(prg,data+pos,prg_len);
	pos += prg_len;
	//fread(prg, prg_len, 1, f);

	int chr_len;
	uint8_t* chr;
	// provide chr-rom/ram if not in file
	if (header.NumCHR == 0) {
		chr_len = 8192;
		chr = new uint8_t[8192];
	}
	// read chr-rom bank(s)
	else {
		chr_len = int(header.NumCHR) * 8192;
		chr = new uint8_t[chr_len];
		memcpy(chr,data+pos,chr_len);
		pos += chr_len;
		//fread(chr, chr_len, 1, f);
	}

	//fclose(f);

	log("Mapper: %d", mapper);
	log("Mirror: %d", mirror);
	log("Battery: %d", battery);
	log("PRG: %dK", header.NumPRG * 16);
	log("CHR: %dK", header.NumCHR * 8);

	// success
	return new Cartridge(prg, prg_len, chr, chr_len, mapper, mirror, battery);
}
