#ifndef BUTTON_H_
#define BUTTON_H_
#include "base.h"
#include <string.h>
#include <stdlib.h>
typedef struct fbutton
{
	int type;//类型
    int id;//控件id
	float left;//左
	float top;//顶部
	float right;//右
	float bottom;//底部
	char* text;//文字
	float text_x;//文字坐标
	float text_y;
	int textSize;//字体大小
	int textColor;//字体颜色
	int drawRectColor;
	char* bacnkground;//背景颜色
	jobject bitmap;//位图
	int fromLeft;//绘制位图区域
	int fromTop;
	int fromRight;
	int fromBottom;
	char bitmapFlag;
	struct fbutton* Prior;//指向前驱节点
	struct fbutton* Next;//指向后继节点
}FBUTTON, *PBUTTON;

extern PBUTTON createButton();//创建
extern PBUTTON addButton(PBUTTON, int, int, const char* , float, float, float, float, int, int, const char* );//结构体指针，类型，id, 文字，x, y, w, h, 字体大小，字体颜色，控件背景, 
extern int traverseListDraw(PBUTTON);//绘图
extern void clearButton(PBUTTON);//清空
extern void deleteButton(PBUTTON* );//销毁
extern PBUTTON seekId(PBUTTON, int);//查找id, 返回节点
extern int removeButton(PBUTTON, int);//删除Button
extern int setButtonBackground(PBUTTON, int, int, jobject);//替换Button按钮背景，头指针，id, 背景颜色，背景bitmap(非NULL时优先设置bitmap)
extern int setButtonText(PBUTTON, int, const char* , int, int, const char* );//设置Button文本 头指针，id, 文本，颜色，大小，显示位置,center, left，right, top, bottom
extern int setButtonPosition(PBUTTON, int, float, float, float, float);//重新设置Button显示位置 头指针，id, x, y, w, h
extern int buttonEvent(PBUTTON, int* , float, float);//Button按键事件
extern int setButtonBitmapDrawArea(PBUTTON, int , int, int, int, int);//设置Button背景位图绘制的区域 头指针，id, fromLeft, fromTop, fromRight, fromBottom 从位图的哪一部分开始画
#endif