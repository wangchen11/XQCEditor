#include <iostream>
using namespace std;

/**
 * 传值，
 * 此方法不会修改传入的变量值
 */
void fun1(int a)
{
	a++;
}

/**
 * 传引用，
 * 此方法可以修改传入的变量值
 */
void fun2(int &a)
{
	a++;
}

/**
 * 传指针，
 * 此方法可以修改传入的变量值
 */
void fun3(int *a)
{
	(*a)++;
}


int main()
{
	int a=0;
	cout << "初始值:" << a << endl;
	fun1(a);
	cout << "fun1后:" << a << endl;
	fun2(a);
	cout << "fun2后:" << a << endl;
	fun3(&a);
	cout << "fun3后:" << a << endl;
	return 0;
}