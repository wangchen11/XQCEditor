/**
 * 包含输入输出库文件
 */
#include <iostream>

/**
 * 使用std命名空间,这样就能使用cin和cout了
 */
using namespace std;

/**
 * 主函数，和c一样
 */
int main()
{
	int input;
	cout << "请输入一个数:" << endl;
	cin >> input;
	cout << "你输入的数为:" << input <<endl ;
	return 0;
}