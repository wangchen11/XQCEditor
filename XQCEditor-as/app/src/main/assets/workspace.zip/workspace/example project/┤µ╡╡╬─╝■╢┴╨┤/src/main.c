#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/*
(1)assets目录下的建议文件作为只读文件，尽量别在里面写入存档文件
(2)assets/elf.elf 为当前程序的可执行文件，要是把自己删了可就不好玩了。所以尽量别在assets目录下进行写操作。
*/

#define SAVE_FILE "save.txt"

int main()
{
	system("clear");
	
	char cwd[100] = "";
	getcwd(cwd,sizeof(cwd));
	printf("save file is:%s/%s =\n",cwd,SAVE_FILE);
	
	FILE*fp = fopen(SAVE_FILE,"rb");
	if(!fp){
		printf("no save file.\n");
	}else{
		char line[100] = "";
		fgets(line,sizeof(line),fp);
		printf("%s\n",line);
		fclose(fp);
	}
	char newLine[100]="";
	printf("input text to save:");
	if(!gets(newLine))
		return 0;
	
	fp = fopen(SAVE_FILE,"w+");
	
	if(!fp){
		printf("ubable open file.to save.\n");
		return 0;
	}
	fwrite(newLine,1,strlen(newLine),fp);
	fclose(fp);
	return 0;
}