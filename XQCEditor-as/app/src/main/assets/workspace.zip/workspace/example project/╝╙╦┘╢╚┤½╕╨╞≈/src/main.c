#include <stdio.h>
#include <stdlib.h>
#include <android/sensor.h>


/*
传感器的使用
by wangchen11

欢迎使用<快写代码>学习c/c++

快写代码:
链接错误请在qeditor.project中的other_option加上-landroid就像:
<other_option>-landroid</other_option>

c4droid:
链接错误请加上android链接库:
若采用gcc编译则在GCC参数里加 -landroid
若采用g++编译则在G++参数里加 -landroid
*/
volatile static int sAlive = 1;


#define SAMP_PER_SEC 100  //采样率，单位:次每秒

int main()
{
	ASensorManager* sensorManager = ASensorManager_getInstance();
	if(sensorManager==NULL) {
		printf("无法获取到传感器管理器实例");
		return -1;
	}
	const ASensor* accSensor = ASensorManager_getDefaultSensor(sensorManager,ASENSOR_TYPE_ACCELEROMETER);
	if(accSensor==NULL) {
		printf("无法获取到传感器实例。");
		return -1;
	}
	const int looperId = 1;
	ALooper* looper = ALooper_prepare(ALOOPER_PREPARE_ALLOW_NON_CALLBACKS);
	ASensorEventQueue* sensorEventQueue = ASensorManager_createEventQueue(sensorManager,looper,looperId,NULL,NULL);
	ASensorEventQueue_enableSensor(sensorEventQueue,accSensor);
	ASensorEventQueue_setEventRate(sensorEventQueue,accSensor,(1000L/SAMP_PER_SEC)*1000);
	
	
	int ident = 0;
	int eventCount = 0;
	while(sAlive) {
		while((ident=ALooper_pollAll(-1,NULL,&eventCount,NULL))>=0){
			if(looperId==ident){
				ASensorEvent event;
				while(ASensorEventQueue_getEvents(sensorEventQueue,&event,1)>0){
					system("clear");
					printf("x=%.4f y=%.4f z=%.4f\n",
							event.acceleration.x,
							event.acceleration.y,
							event.acceleration.z
							);
				}
			}
		}
	}
	
	ASensorManager_destroyEventQueue(sensorManager,sensorEventQueue);
	
	return 0;
}