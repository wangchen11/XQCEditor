#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/*
从快写代码2.3.0版本开始支持assets资源读写，请确保版本已更新。
控制台程序可以直接访问assets目录了，打包成apk也可以。
assets目录下的资源会打包到apk中，每次安装apk后第一次打开会释放assets资源。
注意:
(1)assets目录下的建议文件作为只读文件
(2)assets/elf.elf 为当前程序的可执行文件，要是把自己删了可就不好玩了。所以尽量别在assets目录下进行写操作。
*/

#define TEST_FILE "assets/test.txt"

int main()
{
	system("clear");
	
	char cwd[100] = "";
	getcwd(cwd,sizeof(cwd));
	printf("read line form:%s/%s =\n",cwd,TEST_FILE);
	
	FILE* fp = fopen(TEST_FILE,"rb");
	if(!fp){
		printf("fopen return NULL.\n");
		return 0;
	}
	
	char line[100] = "";
	fgets(line,sizeof(line),fp);
	printf("%s\n",line);
	
	fclose(fp);
	return 0;
}