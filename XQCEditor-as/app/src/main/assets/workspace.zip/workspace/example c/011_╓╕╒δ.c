#include <stdio.h>
#include <stdlib.h>
//指针的使用方法与数组几乎一致 
int main()
{
	char  *ch_p;
	short *sh_p;
	int   *in_p;
	
	ch_p = (char  *)malloc( sizeof(char)*10 );//为其申请内存 
	sh_p = (short *)malloc( sizeof(short)*10 );
	in_p = (int   *)malloc( sizeof(int)*10 );
	
	ch_p[0] = 0;//与 *ch_p = 0 等价
	*ch_p   = 0;
	
	ch_p[1] = 1;//与 *(ch_p+1) = 1 等价 
	*(ch_p+1) =1;
	
	for(int i=0;i<10;i++)
	{
		ch_p[i]=i*i;//与 *(ch_p+i)=i*i 等价
		*(ch_p+i)=i*i;
		
		
		sh_p[i]=i*i*i;//与 *(sh_p+i)=i*i*i 等价
		*(sh_p+i)=i*i*i;
		
		
		in_p[i]=i*i*i*i;//与 *(in_p+i)=i*i*i*i 等价
		*(in_p+i)=i*i*i*i;
	}
	
	
	for(int i=0;i<10;i++)
	{
		printf("ch:%d  sh:%d  in:%d\n",ch_p[i],sh_p[i],in_p[i]);
	}
	
	free(ch_p);//内存用完后需要释放
	ch_p = NULL;//释放后指针最好置为NULL ！以便在出错时容易定位。
	free(sh_p);
	sh_p = NULL;
	free(in_p);
	in_p = NULL;
	return 0;
}