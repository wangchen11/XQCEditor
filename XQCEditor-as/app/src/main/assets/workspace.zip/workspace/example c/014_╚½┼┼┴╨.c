#include <stdio.h>

void fun(int array[],int len,int pos1);
void printArray(int array[],int len);

int main()
{
	printf("start\n");
	int array[]={
		1,4,7,9
	};
	fun(array,sizeof(array)/sizeof(int),0);
	return 0;
}

void fun(int array[],int len,int pos1)
{
	if(pos1>=len-1)
	{
		printArray(array,len);
	}
	else
	{
		for(int i=pos1;i<len;i++)
		{
			int temp;
			temp=array[pos1];
			array[pos1]=array[i];
			array[i]=temp;
			
			fun(array,len,pos1+1);
			
			temp=array[pos1];
			array[pos1]=array[i];
			array[i]=temp;
		}
	}
}

void printArray(int array[],int len)
{
	for(int i=0;i<len;i++)
	{
		printf("%d\t",array[i]);
	}
	printf("\n");
}
