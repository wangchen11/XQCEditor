#include <stdio.h>
#include <math.h>
//函数在使用前，需要先告诉编译器函数的参数和返回值，
//否则编译器会根据你的调用来猜测函数的参数的返回值。
int max(int n1,int n2);

int main(void)
{
	int a=0,b=0;
	
	printf("请输入两个数以判断最大的一个数\n");
	scanf("%d%d",&a,&b);
	printf("最大的一个数为:%d\n",max(a,b));
	system("exit");
	return 0;
}

int max(int n1,int n2)
{
	
	if(n1 > n2)
		return n1;
	else 
		return n2;
}
