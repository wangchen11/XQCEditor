#include <stdio.h>

/*
程序的输入
by 望尘11
*/

int main(void)
{
	int number=0;
	printf("请输入一个数:");
	scanf("%d",&number);
	printf("你输入的数为%d,它的平方为:%d\n",number,number*number);
	return 0;
}