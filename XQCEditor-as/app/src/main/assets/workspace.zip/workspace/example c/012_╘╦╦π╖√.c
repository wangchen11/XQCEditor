#include <stdio.h>
#define INT_SIGN_BIT 0x80000000 //int类型的符号位 
//以2进制输出integer 
void putInteger(int integer);

#define FALSE 0 //0为假
#define TRUE (!FALSE) //非0为真

int main()
{
	int d1;
	int d2;
	d1 = 12;
	d2 = 6;
	
	//以下算数运算
	printf("%d+%d=%d\n",d1,d2, d1+d2 );//加
	printf("%d-%d=%d\n",d1,d2, d1-d2 );//减
	
	printf("%d*%d=%d\n",d1,d2, d1*d2 );//乘
	printf("%d/%d=%d\n",d1,d2, d1/d2 );//除
	
	printf("%d%%%d=%d\n",d1,d2, d1%d2 );//取余数 
	
	
	//以下是位运算
	printf("\n\n\n");
	putInteger(d1);
	printf("&\n");//按位与 
	putInteger(d2);
	printf("=\n");
	putInteger(d1&d2);
	
	printf("\n\n\n");
	putInteger(d1);
	printf("|\n");//按位或
	putInteger(d2);
	printf("=\n");
	putInteger(d1&d2);
	
	printf("\n\n\n");
	//putInteger(d1);
	printf("~\n");//按位取反(非)
	putInteger(d2);
	printf("=\n");
	putInteger(~d2);
	
	printf("\n\n\n");
	putInteger(d1);
	printf("^\n");//按位异或
	putInteger(d2);
	printf("=\n");
	putInteger(d1^d2);
	
	//以下是逻辑运算
	int b1;
	int b2;
	b1 = TRUE;
	b2 = FALSE;
	printf("\n\n\n");
	printf("%d&&%d=%d\n",b1,b2,b1&&b2);//逻辑与
	printf("%d||%d=%d\n",b1,b2,b1||b2);//逻辑或
	printf("!%d=%d\n",b1,!b1);//逻辑非
	
	int c1;
	int c2;
	c1=5;
	c2=7;
	//比较运算
	printf("\n\n\n");
	printf("%d> %d=%d\n",c1,c2,c1>c2);
	printf("%d>=%d=%d\n",c1,c2,c1>=c2);
	printf("%d< %d=%d\n",c1,c2,c1<c2);
	printf("%d<=%d=%d\n",c1,c2,c1<=c2);
	printf("%d==%d=%d\n",c1,c2,c1==c2);
}

//以2进制输出integer
void putInteger(int integer)
{
	int bk=integer;
	for(int i=0;i<32;i++)
	{
		if( (i)%4==0 )
			printf(" ");
		printf("%d",  (integer&INT_SIGN_BIT)!=0 );
		integer<<=1;
	}
	printf(":%d\n",bk);
}




