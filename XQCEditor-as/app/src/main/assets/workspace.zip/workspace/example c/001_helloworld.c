#include <stdio.h>

/*
这是一个简单的helloworld程序
这个程序只做一件事:输出hello world
by 望尘11
*/

int main(void)
{
	printf("hello world!\n");
	return 0;
}
