#include <stdio.h>

int fun(int n);

int main(void)
{
	int number;
	printf("请输入一个数以求其累加:");
	scanf("%d",&number);
	printf("%d的累加为:%d\n",number,fun(number));
	return 0;
}

//获取n的累加  fun(n) = n+(n-1)+(n-2)+ ... +1 
int fun(int n)
{
	if(n<=1)
		return 1;
	return n+fun(n-1);
}