#include <stdio.h>

//联合体的每一成员占同一内存 
union  integer_st{
	int integer;
	struct {
		char low8;
		char low16;
		char high8;
		char high16;
	};
};

int main()
{
	union integer_st integer;
	integer.integer=0x12345678;
	printf("%02x %02x %02x %02x\n",integer.high16,integer.high8,integer.low16,integer.low8);
	return 0;
}