#include <stdio.h>

/*
by 望尘11
*/

int main(void)
{
	int number=0;
	int sum=0;
	
	printf("请输入一个数:");
	scanf("%d",&number);
	for(int i=0;i<=number;i=i+1)
	{
		sum=sum+i;
	}
	printf("你输入的数为%d,它的累加为:%d\n",number,sum);

	sum=1;
	while( number>1 )
	{
		sum=sum*number;
		number=number-1;
	}
	printf("它的阶乘为:%d\n",sum);
	return 0;
}
