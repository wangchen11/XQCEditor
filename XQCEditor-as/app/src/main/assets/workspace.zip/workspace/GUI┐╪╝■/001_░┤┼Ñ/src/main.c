#include "base.h"

//如果要使用LOGI,和LOGE请定义LOG_TAG这个宏
#define  LOG_TAG    "main"

void onClick(View view,void *data)
{
	showToastText("按钮按下",0);
}

//在程序启动时调用
void onCreate()
{
	//创建一个按钮
	Button button = newButton();
	//设置主视图为button
	setContentView(button);
	//设置文本内容
	TextView_setTextEx(button,"按钮");
	//设置按钮回调
	View_setOnClickListener(button,onClick,NULL);
	//删掉该按钮在c中的引用，注意，它在java中还有引用
	deleteButton(button);
}

//触摸事件调用
void onTouchEvent(int action,float x,float y,int index,int count,float pointersX[],float pointersY[],int pointersId[])
{
}

//只能在这里绘图
void onDraw(int left,int top,int right,int bottom,Canvas canvas)
{
}


//屏幕大小发生变化时被调用 ，程序在启动后会调用一次
void onSizeChange(int w,int h,int oldw,int oldh,float density)
{
}

//系统每1毫秒就会调用这个方法1次
void onLoopCall()
{
}

//返回键被按下事件，如果 返回0则退出程序，
int onBackPressed()
{
	return 0;
}

//应用被暂停时调用，例如被后台运行
void onPause()
{
	showToastText("onPause",0);
}

//应用被恢复时调用，例如从后台运行转为前台运行
void onResume()
{
	showToastText("onResume",0);
}

//程序在被销毁时调用
void onDestroy()
{
}
