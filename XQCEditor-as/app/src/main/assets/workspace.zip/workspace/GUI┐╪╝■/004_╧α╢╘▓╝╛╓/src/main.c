#include "base.h"

//如果要使用LOGI,和LOGE请定义LOG_TAG这个宏
#define  LOG_TAG    "main"

//在程序启动时调用
void onCreate()
{
	RelativeLayout layout = newRelativeLayout();
	setContentView(layout);
	Button button1 = newButton();
	Button button2 = newButton();
	Button button3 = newButton();
	TextView_setTextEx(button1,"button1");
	TextView_setTextEx(button2,"button2");
	TextView_setTextEx(button3,"button3");

	//相对布局参数
	RLayoutParams rlp1 = newRLayoutParams(WRAP_CONTENT,WRAP_CONTENT);
	RLayoutParams rlp2 = newRLayoutParams(WRAP_CONTENT,WRAP_CONTENT);
	RLayoutParams rlp3 = newRLayoutParams(WRAP_CONTENT,WRAP_CONTENT);

	//在父视图中居中
	RLayoutParams_addRule(rlp1,RL_CENTER_IN_PARENT,RL_TRUE);

	//水平居中
	RLayoutParams_addRule(rlp2,RL_CENTER_HORIZONTAL,RL_TRUE);

	//垂直居中
	RLayoutParams_addRule(rlp3,RL_CENTER_VERTICAL,RL_TRUE);

	View_setLayoutParams(button1,rlp1);
	View_setLayoutParams(button2,rlp2);
	View_setLayoutParams(button3,rlp3);

	ViewGroup_addView(layout,button1);
	ViewGroup_addView(layout,button2);
	ViewGroup_addView(layout,button3);

	//以下仅仅删除了c中的引用，但是java中的引用任然存在
	deleteRelativeLayout(layout);
	deleteButton(button1);
	deleteButton(button2);
	deleteButton(button3);
	deleteRLayoutParams(rlp1);
	deleteRLayoutParams(rlp2);
	deleteRLayoutParams(rlp3);
}

//触摸事件调用
void onTouchEvent(int action,float x,float y,int index,int count,float pointersX[],float pointersY[],int pointersId[])
{
}

//只能在这里绘图
void onDraw(int left,int top,int right,int bottom,Canvas canvas)
{
	Canvas_drawColor(canvas,RGB(255,255,255));
	Paint paint = newPaint();//创建画笔
	Paint_setTextSize(paint,32);//设置文字大小
	Canvas_drawText(canvas,"Hello world!",100,100,paint);//绘制文本
	deletePaint(paint);//释放画笔
}


//屏幕大小发生变化时被调用 ，程序在启动后会调用一次
void onSizeChange(int w,int h,int oldw,int oldh,float density)
{
}

//系统每1毫秒就会调用这个方法1次
void onLoopCall()
{
}

//返回键被按下事件，如果 返回0则退出程序，
int onBackPressed()
{
	return 0;
}

//应用被暂停时调用，例如被后台运行
void onPause()
{
	showToastText("onPause",0);
}

//应用被恢复时调用，例如从后台运行转为前台运行
void onResume()
{
	showToastText("onResume",0);
}

//程序在被销毁时调用
void onDestroy()
{
}
