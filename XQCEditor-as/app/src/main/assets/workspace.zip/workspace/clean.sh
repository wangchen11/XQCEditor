#删除功能十分危险，请不要随意修改此文件的内容
echo 删除elf文件
find /sdcard/qeditor/workspace/ -name "*.elf" -print0|xargs -0 -t rm -rf
#echo 删除so文件
#find /sdcard/qeditor/workspace/ -name "*.so" -print0|xargs -0 -t rm -rf
echo 删除bin目录
find /sdcard/qeditor/workspace/ -name "bin" -print0|xargs -0 -t rm -rf
echo 删除完成
