#include "SDL2/SDL.h"
#include <stdlib.h>

int mIsAlive = 1;

int main(int args, char *argv[])
{
	if (SDL_Init(SDL_INIT_EVERYTHING) == -1){
		SDL_LogError(0,"%s",SDL_GetError());
		return -1;
	}

	SDL_Window *win = NULL;
	win = SDL_CreateWindow("Hello World!", 0, 0, 1920, 1080, SDL_WINDOW_FULLSCREEN|SDL_WINDOW_OPENGL|SDL_WINDOW_SHOWN);
	if (win == NULL){
		SDL_LogError(0,"%s",SDL_GetError());
		return -1;
	}
	SDL_Renderer *ren = NULL;
	ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_TARGETTEXTURE);
	if (ren == NULL){
		SDL_LogError(0,"%s",SDL_GetError());
		return -1;
	}
	SDL_SetRenderDrawBlendMode(ren,SDL_BLENDMODE_BLEND);

	mIsAlive = 1;
	while(mIsAlive)
	{
		float x=0,y=0;
		SDL_Event event;
		while(SDL_PollEvent(&event))
		{
			if(event.type == SDL_QUIT){
				mIsAlive = 0;
				break;
			}

			if(event.type == SDL_KEYUP)
			if(SDL_GetKeyFromName("AC Back") == event.key.keysym.sym )
			{
				SDL_Log("SDL_KEYUP:%s",SDL_GetKeyName(event.key.keysym.sym));
				mIsAlive = 0;
				break;
			}

			if( (event.type == SDL_FINGERDOWN) || (event.type == SDL_FINGERMOTION)){
				x = event.tfinger.x;
				y = event.tfinger.y;
			}
		}
		SDL_SetRenderDrawColor(ren,255,255,255,255);
		SDL_RenderClear(ren);

		{
			// TODO drawing here
			int screenW,screenH;
			SDL_GetRendererOutputSize(ren,&screenW,&screenH);
			SDL_SetRenderDrawColor(ren,0,0,0,255);
			SDL_RenderDrawLine(ren,x*screenW,0,x*screenW,screenH);
			SDL_RenderDrawLine(ren,0,y*screenH,screenW,y*screenH);
		}

		SDL_RenderPresent(ren);
		SDL_Delay(20);
	}

    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    SDL_Quit();
	return 0;
}

